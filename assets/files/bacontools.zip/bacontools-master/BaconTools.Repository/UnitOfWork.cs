using BaconTools.Data.Interfaces;
using BaconTools.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BaconTools.Repository
{


    public class UnitOfWork : IUnitOfWork 
    {
        private readonly IBaconToolsDbContextFactory _dbContextFactory;
        private readonly Dictionary<Type, object> _repositories;


        public UnitOfWork(IBaconToolsDbContextFactory dbContextFactory)
        {
            _repositories = new Dictionary<Type, object>();
            _dbContextFactory = dbContextFactory;
            
        }

        public IRepository<TEntity> GetRepository<TEntity>() where TEntity: class
        {
            if (_repositories.Keys.Contains(typeof(TEntity)))
            {
                return _repositories[typeof(TEntity)] as IRepository<TEntity>;
            }

            var repository = new Repository<TEntity>(_dbContextFactory.GetDbContextForEntity<TEntity>());
            _repositories.Add(typeof(TEntity), repository);

            return repository;

        }

        public int SaveChanges()
        {
            return _dbContextFactory.SaveChanges();
        }

    }
}
