using BaconTools.Data.Interface;
using BaconTools.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Metadata.Edm;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Linq.Expressions;
using LinqKit;
namespace BaconTools.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly IBaconToolsDbContext _dbContext;
        private readonly DbSet<T> _dbSet;
        public Repository(IBaconToolsDbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = dbContext.Set<T>();
        }

        public T Single(object key)
        {
            var obj = Find(key);

            if (obj == null) throw new ArgumentNullException("No Item found");

            return obj;
        }
        public T Find(object key)
        {
            return _dbSet.Find(key);
        }

        public IEnumerable<T> Query(Expression<Func<T, bool>> filter = null, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, params Expression<Func<T, object>>[] includes)
        {
            IQueryable<T> query = _dbSet;

            foreach (Expression<Func<T, object>> include in includes)
                query = query.Include(include);

            if (filter != null)
                query = query.Where(filter);

            if (orderBy != null)
                query = orderBy(query);

            return query;
        }
        public IEnumerable<T> Query(Expression<Func<T, bool>> filter, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy)
        {
            IQueryable<T> query = _dbSet;

            if (filter != null)
                query = query.Where(filter);

            if (orderBy != null)
                query = orderBy(query);

            return query;
        }

        public IEnumerable<T> Query(Expression<Func<T, bool>> match)
        {
            return _dbSet.Where(match);
        }

        public IEnumerable<T> GetAll(params Expression<Func<T, object>>[] includes)
        {
            var query = _dbSet.AsExpandable();

            return includes.Aggregate(query.AsQueryable(), (current, include) => current.Include(include));

        }

        public IEnumerable<T> GetAll()
        {
            var query = _dbSet;
            return query;
        }

        public T Update(T entity, object key)
        {
            if (entity == null)
                return null;
            var exist = Find(key);
            if (exist != null)
            {
                _dbContext.Entry(exist).CurrentValues.SetValues(entity);
            }
            return exist;
        }

        public T Add(T entity)
        {
            _dbSet.Add(entity);
            return entity;
        }

        public IEnumerable<T> AddRange(IEnumerable<T> entities)
        {
            var returnObj = new List<T>();
            foreach(var entity in entities)
            {
                returnObj.Add(Add(entity));
            }
            return returnObj;
        }
           

        public void Delete(T entity)
        {
            _dbSet.Remove(entity);
        }

        public void Delete(object key)
        {
            var entity = Find(key);
            if (entity != null) Delete(entity);
        }

    }
}
