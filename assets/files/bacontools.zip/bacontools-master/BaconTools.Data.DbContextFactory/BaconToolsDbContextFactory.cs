using BaconTools.Data.Core;
using BaconTools.Data.DbContextFactory.Extensions;
using BaconTools.Data.Interface;
using BaconTools.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BaconTools.Data
{
    public class BaconToolsDbContextFactory : IBaconToolsDbContextFactory
    {
        private readonly List<IBaconToolsDbContext> _dbContexts;

        public BaconToolsDbContextFactory(BaconToolsCoreDbContext BaconToolsCoreDbContext)
        {
            _dbContexts = new List<IBaconToolsDbContext>
            {
                BaconToolsCoreDbContext
            };
        }

        public IBaconToolsDbContext GetDbContextForEntity<TEntity>() where TEntity : class
        {
            foreach (var BaconToolsDbContext in _dbContexts)
            {
                if (BaconToolsDbContext.EntityExists<TEntity>()) return BaconToolsDbContext;
            }

            throw new ArgumentOutOfRangeException(typeof(TEntity).Name, "Entity does not exist in any provided dbContext");
        }

        public int SaveChanges()
        {
            return _dbContexts.Where(c => !c.ReadOnly).Sum(dbContext => dbContext.SaveChanges());
        }

    }
}
