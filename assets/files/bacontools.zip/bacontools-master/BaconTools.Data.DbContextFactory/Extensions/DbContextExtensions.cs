using BaconTools.Data.Interface;
using System.Data.Entity.Core.Metadata.Edm;
using System.Data.Entity.Infrastructure;
using System.Linq;

namespace BaconTools.Data.DbContextFactory.Extensions
{
    public static class DbContextExtensions
    {
        /// <summary>
        /// Checks if the provided class exists in the IDeqDbContext
        /// </summary>
        public static bool EntityExists<TEntity>(this IBaconToolsDbContext dbContext) where TEntity : class
        {
            var entityName = typeof(TEntity).FullName;
            var objContext = ((IObjectContextAdapter)dbContext).ObjectContext;
            var workspace = objContext.MetadataWorkspace;
            return workspace.GetItems<EntityType>(DataSpace.OSpace).Any(e => e.FullName == entityName);
        }
    }
}
