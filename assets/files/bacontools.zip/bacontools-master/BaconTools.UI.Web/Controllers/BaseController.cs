using BaconTools.Model.Core.Config;
using BaconTools.Model.Identity;
using BaconTools.Service.Core.Interface;
using BaconTools.UI.Web.Helpers;
using BaconTools.UI.Web.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using BaconTools.Web.Models;
using Microsoft.AspNetCore.Http;

namespace BaconTools.UI.Web.Controllers
{

    public class BaseController : Controller
    {
        internal readonly IHttpContextAccessor httpContextAccessor;
        internal readonly SignInManager<ApplicationUser> signInManager;
        internal readonly AppSettings appSettings;
        internal ICurrentUserService currentUserService;
        internal RoleManager<IdentityRole<int>> roleManager;
        public virtual string Name { get; }

        public BaseController(IHttpContextAccessor httpContextAccessor, RoleManager<IdentityRole<int>> roleManager, ICurrentUserService currentUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager)
        {
            this.currentUserService = currentUserService;
            this.roleManager = roleManager;
            this.signInManager = signInManager;
            this.appSettings = appSettingsService.AppSettings;     
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            ViewData["MyCookie"] = Request.Cookies["MenuMemory"];


            base.OnActionExecuting(filterContext);
        }

        protected void Success(string message, bool dismissable = false)
        {
            AddAlert(AlertStyles.Success, message, dismissable);
        }

        protected void Danger(string message, bool dismissable = false)
        {
            AddAlert(AlertStyles.Danger, message, dismissable);
        }

        private void AddAlert(string alertStyle, string message, bool dismissable)
        {
            var alerts = TempData.ContainsKey(Alert.TempDataKey)
                ? TempData.Get<List<Alert>>(Alert.TempDataKey)
                : new List<Alert>();

            alerts.Add(new Alert
            {
                AlertStyle = alertStyle,
                Message = message,
                Dismissable = dismissable
            });

            TempData.Put(Alert.TempDataKey,alerts);
        }


        protected async Task<string> RenderViewAsync<TModel>(string viewName, TModel model, bool partial = false)
        {
            if (string.IsNullOrEmpty(viewName))
            {
                viewName = ControllerContext.ActionDescriptor.ActionName;
            }

            ViewData.Model = model;

            using (var writer = new StringWriter())
            {
                IViewEngine viewEngine = HttpContext.RequestServices.GetService(typeof(ICompositeViewEngine)) as ICompositeViewEngine;
                ViewEngineResult viewResult = viewEngine.FindView(ControllerContext, viewName, !partial);

                if (viewResult.Success == false)
                {
                    return $"A view with the name {viewName} could not be found";
                }

                ViewContext viewContext = new ViewContext(
                    ControllerContext,
                    viewResult.View,
                    ViewData,
                    TempData,
                    writer,
                    new HtmlHelperOptions()
                );

                await viewResult.View.RenderAsync(viewContext);

                return writer.GetStringBuilder().ToString().Replace("\r", "").Replace("\r\n","");
            }
        }

        protected async Task<IActionResult> RenderJsonReturn(string view, object model, string message = null)
        {
            var htmlView = await RenderViewAsync(view, model, true);

            return Json(new JsonReturn(message, true, htmlView));
        }


    }
}