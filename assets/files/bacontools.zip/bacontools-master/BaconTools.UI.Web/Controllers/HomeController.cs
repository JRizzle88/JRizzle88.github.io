using BaconTools.Model.Identity;
using BaconTools.Service.Core.Interface;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Web;
using BaconTools.Web.Models.ViewModels;
using BaconTools.Model.Core;
using System.Collections.Generic;
using System.Linq;
using BaconTools.Util;
using System;
using System.Globalization;
using BaconTools.UI.Web.Helpers;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using ElmahCore;
using BaconTools.Service.Core;
using BaconTools.Model.Core.ViewModels;
using BaconTools.Util.Extension;
using BaconTools.Web.Models;

namespace BaconTools.UI.Web.Controllers
{
    public class HomeController : BaseController
    {

        private IHostingEnvironment environment;
        private IGuildPostionsService guildPostionsService;

        public HomeController(IGuildPostionsService guildPostionsService, IHttpContextAccessor httpContextAccessor, IHostingEnvironment environment,ICurrentUserService currentUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
            : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.environment = environment;
            this.guildPostionsService = guildPostionsService;
        }

        
        public IActionResult Index()
        {

            try
            {
                return RedirectToAction("Index", "Default", new { Area = "Portal" });
            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return RedirectToAction("Error","Home");
            }

        }



    }
}
