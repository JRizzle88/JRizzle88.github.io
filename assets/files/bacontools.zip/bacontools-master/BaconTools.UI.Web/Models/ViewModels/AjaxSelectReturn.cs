﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BaconTools.UI.Web.Models.ViewModels
{

    public class AjaxSelectReturn
    {
        public string value { get; set; }
        public string text { get; set; }
        public string css { get; set; }
        public bool disabled { get; set; }
        public Data data { get; set; }
    }

    public class Data
    {
        public bool divider { get; set; }
        public string subtext { get; set; }
        public string icon { get; set; }
        public string content { get; set; }
    }

}
