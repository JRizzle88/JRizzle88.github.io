using Microsoft.AspNetCore.Mvc.Rendering;
using System;


namespace BaconTools.UI.Web.Models
{
    public class Menu
    {
        public static string HomeIndex => "HomeIndex";
        public static string Login => "Login";
        public static string Registration => "Registration";
        public static string Ledger => "Ledger";
        public static string Setting => "Setting";
        public static string ChangePassword => "ChangePassword";
        public static string Administration => "Administration";
        public static string DuesAdministration => "DuesAdministration";
        public static string OrganizationChart => "OrganizationChart";
        public static string AlbionFightClub => "AlbionFightClub";
        public static string Split => "Splits";
        public static string SplitNavClass(ViewContext viewContext) => PageNavClass(viewContext, Split);
        public static string AlbionFightClubNavClass(ViewContext viewContext) => PageNavClass(viewContext, AlbionFightClub);
        public static string OrganizationChartNavClass(ViewContext viewContext) => PageNavClass(viewContext, OrganizationChart);
        public static string AdministrationNavClass(ViewContext viewContext) => PageNavClass(viewContext, Administration);
        public static string SettingNavClass(ViewContext viewContext) => PageNavClass(viewContext, Setting);
        public static string LedgerNavClass(ViewContext viewContext) => PageNavClass(viewContext, Ledger);
        public static string ChangePasswordNavClass(ViewContext viewContext) => PageNavClass(viewContext, ChangePassword);
        public static string HomeIndexNavClass(ViewContext viewContext) => PageNavClass(viewContext, HomeIndex);
        public static string LoginNavClass(ViewContext viewContext) => PageNavClass(viewContext, Login);
        public static string RegistrationNavClass(ViewContext viewContext) => PageNavClass(viewContext, Registration);
        public static string GatheringTaxAdministrationNavClass(ViewContext viewContext) => PageNavClass(viewContext, DuesAdministration);
        private static string PageNavClass(ViewContext viewContext, string page)
        {
            var activePage = viewContext.ViewData["ActivePage"] as string;
            return string.Equals(activePage, page, StringComparison.OrdinalIgnoreCase) ? "active" : null;
        }
    }
}
