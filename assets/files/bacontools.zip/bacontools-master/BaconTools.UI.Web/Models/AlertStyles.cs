namespace BaconTools.UI.Web.Models
{
    public static class AlertStyles
    {
        public const string Success = "success";
        public const string Danger = "danger";
    }
}