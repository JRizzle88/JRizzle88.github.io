using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace BaconTools.Web.Models
{
    public class JsonReturn
    {

        public JsonReturn(List<string> messages, object payload)
        {
            Messages = messages;
            Payload = payload;
        }

        public JsonReturn(string message, object payload)
        {
            Messages = new List<string>()
            {
                message
            };

            Payload = payload;

        }

        public JsonReturn(string message, bool success)
        {
            Messages = new List<string>()
            {
                message
            };
            Success = success;
        }


        public JsonReturn(List<string> messages, bool success)
        {
            Messages = messages;
            Success = success;
        }

        public JsonReturn(string message, bool success, object payload)
        {
            Messages = new List<string>()
            {
                message
            };
            Success = success;
            Payload = payload;
        }


        public JsonReturn(List<string> messages, bool success, object payload)
        {
            Messages = messages;
            Success = success;
            Payload = payload;
        }



        public List<string> Messages { get; set; }
        public bool Success { get; set; } = true;
        public object Payload { get; set; }

    }
}
