app.utils.OverLay = (function () {
    $.LoadingOverlaySetup({
        fontawesomeAutoResize: true,
        image: "",
        fontawesome: "fas fa-cog fa-spin"
        
    });

    var Show = function (ele) {
        $.LoadingOverlay("show");
    }

    var Hide = function (all, ele) {
        $.LoadingOverlay('hide');
    }
   

    return {
        Show: Show,
        Hide: Hide
    }
    

}())