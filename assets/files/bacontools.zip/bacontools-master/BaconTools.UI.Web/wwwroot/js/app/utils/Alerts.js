app.utils.alerts = (function () {

    var returnObj = {}

    returnObj.Info = function(message, dismissable) {
        if (dismissable)
            SendMessage(message, 'pastel-info');
        else
            SendMessage_Sticky(message, 'pastel-info')
    }

    returnObj.Error = function(message, dismissable) {

        if (dismissable)
            SendMessage(message, 'pastel-danger');
        else
            SendMessage_Sticky(message, 'pastel-danger')
    }

    returnObj.Warning = function(message, dismissable) {

        if (dismissable)
            SendMessage(message, 'pastel-warn');
        else
            SendMessage_Sticky(message, 'pastel-warn')

    }

    returnObj.Success = function(message, dismissable) {
        if (dismissable)
            SendMessage(message, 'pastel-success');
        else
            SendMessage_Sticky(message, 'pastel-success')
    }

    var SendMessage_Sticky = function(message, type, title) {
        try {
            $.notify({
                message: message,
            },
                {
                    placement: {
                        from: "top",
                        align: "center"
                    },
                    allow_dismiss: false,
                    type: type,
                    delay: 5000,
                    z_index: 250000,
                    template: '<div data-notify="container" class="col-xs-11 col-sm-3 alert alert-{0}" role="alert">' +
                        '<button type="button" aria-hidden="true" class="close" data-notify="dismiss" style="position: absolute; right: 10px; top: 5px; z-index: 1033;">x</button>' +
                        '<span data-notify="title">{1}</span>' +
                        '<span data-notify="message">{2}</span>' +
                        '</div>'
                });
        } catch (e) {
            console.log(e);
            alert(message);
        }
    }

    var SendMessage = function(message, type, title) {
        try {
            $.notify({
                message: message,
            },
                {
                    placement: {
                        from: "top",
                        align: "center"
                    },
                    allow_dismiss: true,
                    type: type,
                    delay: 0,
                    z_index: 250000,
                    template: '<div data-notify="container" class="col-xs-11 col-sm-3 alert alert-{0}" role="alert">' +
                        '<button type="button" aria-hidden="true" class="close" data-notify="dismiss" style="position: absolute; right: 10px; top: 5px; z-index: 1033;">x</button>' +
                        '<span data-notify="title">{1}</span>' +
                        '<span data-notify="message">{2}</span>' +
                        '</div>'
                });
        } catch (e) {
            console.log(e);
            alert(message);
        }
    }

    return returnObj
})();