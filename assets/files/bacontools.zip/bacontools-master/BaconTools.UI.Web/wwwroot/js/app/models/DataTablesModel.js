app.models.DataTablesModel = (function (ele, options) {

    var _table = {};
    var _element = {};
    var _validelement = false;
    var _publicItems = {};

    var validation = app.validation;

    if (typeof validation === "undefined") throw new Error("app.validation is required.");

    var _options =
    {
        dom: "<'mb-2'B><'dataTables_wrapper dt-bootstrap4 no-footer'<'row'<'col-sm-12 col-md-6'l><'col-md-6'f>>><t><'dataTables_wrapper dt-bootstrap4 no-footer'<'row'<'col-md-6'i><'col-md-6'p>>>",
        buttons: [
            {
                extend: 'csv',
                exportOptions: {
                    rows: ':not(".dontexport")'
                },
                customize: function (csv) {
                    return csv;
                },
                className: 'btn btn-bacon'
            },
            {
                extend: 'copy',
                customize: function (csv) {

                    var newStart = csv.indexOf('\n') + 3

                    return csv.substring(newStart);
                },
                exportOptions: {
                    rows: ':not(".dontexport")'
                },
                className: 'btn btn-bacon'
            }
        ],
        orderCellsTop: true ,
        responsive: true,
        searching: true,
        destroy: true,
        paging: true,
        info: true,
        pageLength: 10,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]]
    }

    if (!validation.isUndefined(options)) {
        $.extend(_options, options);
    }


    if (validation.isjQueryObj(ele)) {
        _validelement = true;
        _element = ele;
    }

    if (validation.isString(ele)) {
        _validelement = true;
        var index = ele.indexOf("#");

        if (index === 0) {
            _element = $(ele);

        } else if (index === -1) {
            _element = $("#" + ele);
        }
    }

    if (!_validelement) {
        throw new Error(validation.errorMessages.ElementNotjQueryOrString);
    }

    if (_element.length === 0) {
        throw new Error(validation.errorMessages.EmptyjQueryObject);
    }

    _table = _element.DataTable(_options);
    _element.css("width", "100%");
    _publicItems.addData = function (data)
    {
        if (validation.isUndefined(data)) {
            throw new Error(validation.errorMessages.DataUndefined);
        }

        if (data.length === 0) {
            return;
        }

        if (validation.isArray(data)) {
            _table.rows.add(data).draw(false);
        } else {
            _table.row.add(data).draw(false);
        }


        
    }

    _publicItems.getRow = function (row) {
        return _table.row(row);
    }
    
    _publicItems.getTable = function(){
        return _table;
    }

    _publicItems.refeshFromHtml = function () {
        var tr = _element.find("tbody tr").toArray();
        _table.clear();
        _publicItems.addData(tr);
    }

    _publicItems.getRowData = function (row) {

        if (validation.isUndefined(row)) {
            throw new Error(validation.errorMessages.RowUndefined);
        }

        return _table.row(row).data();
    }

    _publicItems.getAllRowData = function () {
        return _table.rows().data().toArray();
    }

    _publicItems.removeRowData = function (row)
    {
        if (validation.isUndefined(row)) {
            throw new Error(validation.errorMessages.RowUndefined);
        }

        _table.row(row).remove().draw(false);

    }

    _publicItems.updateRowData = function(row, data) {
        if (validation.isUndefined(row)) {
            throw new Error(validation.errorMessages.RowUndefined);
        }

        if (validation.isUndefined(data)) {
            throw new Error(validation.errorMessages.DataUndefined);
        }

        _table.row(row).data(data).draw(false);
    }

    _publicItems.invalidateAllRows = function () {
        _table.rows().invalidate().draw();
    }

    _publicItems.clear = function () {
        _table.clear().draw();
    }

    return _publicItems;


})