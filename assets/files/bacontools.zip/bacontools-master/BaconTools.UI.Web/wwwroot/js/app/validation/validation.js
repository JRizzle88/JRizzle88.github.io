app.validation.isUndefined = (function(obj) {
    return typeof obj === "undefined";
});

app.validation.isString = (function(obj) {
    return typeof obj === "string";
});

app.validation.isStringUndefinedOrEmpty = (function(obj) {
    return typeof obj === "undefined" || typeof obj != "string" || obj === "";
});

app.validation.isjQueryObj = (function(obj) {
    return typeof obj === "object" && obj instanceof jQuery;
});

app.validation.isArray = (function(obj) {
    return Array.isArray(obj);
});

app.validation.isjQueryForm = (function(obj) {
    return app.validation.isjQueryObj(obj) && obj[0].tagName === 'FORM';
});

app.validation.isjQueryButton = (function (obj) {
    return app.validation.isjQueryObj(obj) && obj[0].tagName === 'BUTTON';
});

app.validation.isjQueryAnchor = (function (obj) {
    return app.validation.isjQueryObj(obj) && obj[0].tagName === 'A';
});

app.validation.isFunction = (function (obj) {
    return typeof obj === "function";
});

app.validation.errorMessages = {
    RowUndefined: "Passed Row is undefined.",
    DataUndefined: "Passed Data is undefined.",
    ElementNotjQueryOrString: "Element must be a JQuery Element or a String Selector.",
    EmptyjQueryObject: "jQuery Element contains 0 items.",
    DataEmpty: "Data Object is Empty.  No items added.",
    OptionsEmpty: "Options Element is Empty.",
    RequiredProperty: "Property is required: ",
    jQueryForm: "Obj must be a Form",
    EmptyString: "Passed parameter must be an un-empty string: ",
    NotAFunction: "Passed Callback was not a Function: "
};