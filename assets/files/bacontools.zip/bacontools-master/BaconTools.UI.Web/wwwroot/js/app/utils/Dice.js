app.utils.dice = (function () {
    var returnObj = {};

    returnObj.RollDie = function (chance) {
        return Math.floor((Math.random() * chance) + 1);
    }
    return returnObj
}())