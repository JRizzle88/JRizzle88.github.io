app.utils.GetDataId = (function(ele) {
    if (!app.validation.isjQueryObj(ele)) {
        throw new Error(app.validation.errorMessages.EmptyjQueryObject + "ele");
    }

    return ele.data("id");

});

app.utils.CreateFormValidation = (function(ele) {

    if (!app.validation.isjQueryObj(ele)) {
        throw new Error(app.validation.errorMessages.EmptyjQueryObject + "ele");
    }

    if (!app.validation.isjQueryForm(ele)) {
        throw new Error(app.validation.errorMessages.jQueryForm);
    }


    ele
        .removeData("validator")
        .removeData("unobtrusiveValidation");

    $.validator.unobtrusive.parse(ele);

});

app.utils.GetQueryStringParamValue = function (name) {

    window.urlParams = typeof window.urlParams === "undefined" ? new URLSearchParams(window.location.search) : window.urlParams
    var param = window.urlParams.get(name);
    return param;

}

app.utils.setUrl = function (title,newUrl) {
    window.history.replaceState({ "pageTitle": "Ledger" }, title, newUrl);
}

app.utils.ToggleSpin = function(element, action)
{

    if (app.validation.isjQueryButton(element) || app.validation.isjQueryAnchor(element)) {
        var i = element.find("i.fa-spinner");
        var ineighbor = i.siblings("i");
        switch (action) {
            case 'spin':
                ineighbor.addClass("hide-spinner");
                i.removeClass("hide-spinner");
                i.addClass("show-spinner");
                break;
            case 'stop':
                i.removeClass("show-spinner");
                i.addClass("hide-spinner");
                ineighbor.removeClass("hide-spinner");
                break;
            default:
                break;
        };
    }


}


app.utils.FormatNumberWithComma = function (x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
};

app.utils.BindAjaxSelectPicker = function (selector, url, data, placeholder) {


    var returnObj =  $(selector)
        .selectpicker({
            liveSearch: true
        })
        .ajaxSelectPicker({
            ajax: {
                url: url,
                data: data
            },
            locale: {
                searchPlaceholder: placeholder,
                emptyTitle: placeholder
            },
            preprocessData: function (data) {

                //dumbass used class as a property so I have to change it in the return
                //this is setting the class property from the css.
                $.each(data, function (i,v) { v.class  = v.css });

                return data;
            },
            preserveSelected: true,
            minLength: 3,
            cache: false,
            log: true

        });

    return returnObj;
}



