﻿app.page = (function () {

    var returnObj = {};


    returnObj.init = function () {
        var owedSplits = {};
        var yourSplits = {};

        var yourSplitsOptions = {
            "order": [[1, 'asc']],
            "drawCallback": function (settings, json) {
                
            }
        };

        $(document).on("click", ".btn-split-add-toon", function () {
            alert("Add Toon");
        });

        $(document).on("click", ".btn-add-split", function () {
            alert("Add Split");
        });

        $(document).on("click",'.show-split-details', function () {

            var tr = $(this).closest('tr');
            var row = yourSplits.getRow(tr);

            if (row.child.isShown())
            {
                row.child.hide();
                tr.removeClass('shown');
            }
            else
            {
                if (typeof row.child.loaded !== true)
                {
                    row.child.loaded = true;
                    row.child("<button type='button' class='btn btn-bacon btn-sm btn-split-add-toon' title='Add Toon'><i class='fa fa-spinner fa-spin hide-spinner'></i><i class='fas fa-user-plus'></i></button>");
                }

                
                row.child.show();
                tr.addClass('shown');

            }
        });
        var owedSplitsOptions = {};

        yourSplits = new app.models.DataTablesModel($("#YourSplits"), yourSplitsOptions)
        owedSplits = new app.models.DataTablesModel($("#OwedSplits"), owedSplitsOptions)
    };

    return returnObj;

}());