﻿app.models.TokenCalculator = (function (ele) {

    var defaultValues = {};
    var container = ele;
    var values = defaultValues;

    $("#BaseFame,#TaxRate,#FreeFame, #Fame").on("input", function () {
        
        values = CreateValuesObj();
        Calculate();
        CalculateDiff();

    });

    var CalculateDiff = function () {


        values.BaseFame === defaultValues.BaseFame ? container.find("#BaseFame").css("background-color", "lightgreen") : container.find("#BaseFame").css("background-color", "lightpink");
        values.TaxRate === defaultValues.TaxRate ? container.find("#TaxRate").css("background-color", "lightgreen") : container.find("#TaxRate").css("background-color", "lightpink");
        values.FreeFame === defaultValues.FreeFame ? container.find("#FreeFame").css("background-color", "lightgreen") : container.find("#FreeFame").css("background-color", "lightpink");

    }

    var Calculate = function () {

        var BaseFame = values.BaseFame;
        var TaxRate = values.TaxRate;
        var FreeFame = values.FreeFame;
        var Fame = values.Fame;
        var TaxedFame = 0;
        var TokenValue = 0;

        TaxedFame = Fame - FreeFame;

        if (TaxedFame > 0 &&  BaseFame > 0 ) {
            TokenValue = ((TaxedFame / BaseFame) * TaxRate).toFixed(2)
        };

        values.TokenValue = TokenValue;

        UpdateUI();
    }

    var UpdateUI = function () {

        container.find("#BaseFame").inputmask('setvalue',values.BaseFame);
        container.find("#TaxRate").inputmask('setvalue',values.TaxRate);
        container.find("#FreeFame").inputmask('setvalue',values.FreeFame);
        container.find("#Fame").inputmask('setvalue',values.Fame);
        container.find("#TokenValue").inputmask('setvalue', values.TokenValue);
        CalculateDiff();
    }

    var CreateValuesObj = function () {

        var values = {};

        values.BaseFame = Number(container.find("#BaseFame").val());
        values.TaxRate = Number(container.find("#TaxRate").val());
        values.FreeFame = Number(container.find("#FreeFame").val());
        values.Fame = Number(container.find("#Fame").val());
        values.TokenValue = Number(container.find("#TokenValue").val());
        return values;
    }

    var returnObj = {};

    returnObj.GetValues = function () {
        CreateValuesObj();
        return values;
    }


    returnObj.Reset = function () {
        values = defaultValues;
        values.Fame = 0;
        values.TokenValue = 0;

        UpdateUI();
    }


    returnObj.SetAsDefaultValues = function () {
        CreateValuesObj();
        defaultValues = values;
    }
    defaultValues = CreateValuesObj();
    return returnObj;

});