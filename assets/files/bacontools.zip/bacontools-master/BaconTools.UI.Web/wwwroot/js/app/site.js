var app = {};
app.utils = {};
app.validation = {};
app.models = {};
app.models.viewmodels = {};
app.page = {};
$.fn.selectpicker.Constructor.BootstrapVersion = '4';



$.fn.extend({
    animateCss: function (animationName, callback) {
        if (this.hasClass('hidden')) {
            this.removeClass('hidden');
        }
        var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        this.addClass('animated ' + animationName).one(animationEnd, function () {
            $(this).removeClass('animated ' + animationName);
            if (callback) {
                callback();
            }
        });
        return this;
    }
});


$("#menu-toggle").click(function (e) {

    e.preventDefault();
    $("#wrapper").toggleClass("toggled");
    $(window).trigger('resizeEnd');
});
$("#menu-toggle-2").click(function (e) {
    e.preventDefault();
    $("#wrapper").toggleClass("toggled-2");
    $('#menu ul').hide();

    $(window).trigger('resizeEnd');
});

$(window).resize(function () {
    if (this.resizeTO) clearTimeout(this.resizeTO);
    this.resizeTO = setTimeout(function () {
        $(this).trigger('resizeEnd');
    }, 100);
});

function initMenu() {

    $('#menu ul').hide();
    $('#menu ul').children('.current').parent().show();
    $('#menu ul:first').show();
    $('#menu li a').click(
        function () {
            var checkElement = $(this).next();
            if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
                return false;
            }
            if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
                $('#menu ul:visible').slideUp('normal');
                checkElement.slideDown('normal');
                return false;
            }
        }
    );



}

function loadTinyMCE(selector) {
    tinymce.init({
        selector: selector,
        height: 500,

        menubar: true,
        plugins: [
            'advlist autolink lists link image charmap print preview anchor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table paste code help wordcount'
        ],
        toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
        content_css: [
            '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
            '//www.tiny.cloud/css/codepen.min.css'
        ]
    });
}

moment.tz.setDefault("United_Kingdom/London");

Inputmask.extendDefaults({
    'autoUnmask': true
});

function TickTock() {
    var date = moment.utc().format('MM/DD/YYYY HH:mm:ss');
    $("#AO-Time").text(date);
}



$(document).ready(function () {
    
    initMenu();
    TickTock();
    
    setInterval(function () {
        TickTock();
    }, 1000);

    $(":input").inputmask();

    if (typeof app.page !== "undefined" && typeof app.page.init === "function") app.page.init();

    $(".datepicker").datepicker({
        uiLibrary: 'bootstrap4'
    });

});