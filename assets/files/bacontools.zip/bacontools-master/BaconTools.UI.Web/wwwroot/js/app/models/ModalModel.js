app.models.ModalModel = (function (ele, options) {


    var _publicItems = {};
    var _element = {};
    var _form = {};
    var _options = {};

    _options.SaveButtonText = "Save Changes";
    _options.CancelButtonText = "Cancel Changes";
    _options.Title = "";
    

    $.extend(_options, options);

    var validation = app.validation;

    if (typeof validation === "undefined") throw new Error("app.validation is required.");

    var _validelement = false;

    if (validation.isjQueryObj(ele)) {
        _validelement = true;
        _element = ele;
        
    }

    if (validation.isString(ele)) {
        _validelement = true;

        var index = ele.indexOf("#");

        if (index === 0) {
            _element = $(ele);

        } else if (index === -1) {
            _element = $("#" + ele);
        }
    }

    if (!_validelement) {
        throw new Error(validation.errorMessages.ElementNotjQueryOrString);
    }

    if (validation.isStringUndefinedOrEmpty(options.Url)) {
        throw new Error(app.validation.errorMessages.EmptyString + " url");
    }

    _publicItems.UpdateTitle = function (title) {
        _element.find(".modal-title").text(title);
    }

    _publicItems.UpdateBody = function (data) {
        _element.find(".modal-body").html(data)
        _form = _element.find("form");
        app.utils.CreateFormValidation(_form);
    }

    _publicItems.OnSave = function (cb) {

        if (!validation.isFunction(cb)) throw new Error(app.validation.errorMessages.NotAFunction + "cb");


        _element.find(".btn-save").on('click',
            function () {
                cb(_publicItems.GetFormData());
            });
    }

    _publicItems.OnCancel = function (cb) {

        if (!validation.isFunction(cb)) throw new Error(app.validation.errorMessages.NotAFunction + "cb");


        _element.find(".btn-cancel").on('click',
            function () {
                cb();
            });
    }

    _publicItems.Show = function (data) {
        
        _element.find(".modal-body").load(_options.Url,
            data,
            function () {
                _form = _element.find("form");
                app.utils.CreateFormValidation(_form);
                _element.modal('show');
            });
    }

    _publicItems.Validate = function() {
        return _form.valid();
    }

    _publicItems.GetFormData = function () {


        return Array.from(new FormData($(_form)[0])).map(function (e, i) { this[e[0]] = e[1]; return this; }.bind({}))[0];
        
    }

    _publicItems.Hide = function () {
        _element.modal('hide');
        _element.find(".modal-body").html("");
    }

    _publicItems.OnShown = function (cb) {
        if (!validation.isFunction(cb)) throw new Error(app.validation.errorMessages.NotAFunction + "cb");


        _element.on('shown.bs.modal',
            function () {
                cb(_element);
            });
    }

    _publicItems.OnShow = function (cb) {
        if (!validation.isFunction(cb)) throw new Error(app.validation.errorMessages.NotAFunction + "cb");


        _element.on('show.bs.modal',
            function () {
                cb(_element);
            });
    }

    _publicItems.OnHide = function (cb) {
        if (!validation.isFunction(cb)) throw new Error(app.validation.errorMessages.NotAFunction + "cb");


        _element.on('hide.bs.modal',
            function () {
                cb(_element);
            });
    }

    _publicItems.OnHidden = function (cb) {
        if (!validation.isFunction(cb)) throw new Error(app.validation.errorMessages.NotAFunction + "cb");


        _element.on('hidden.bs.modal',
            function () {
                cb(_element);
            });
    }

    _publicItems.DisplayErrors = function (errors)
    {
        $("span.field-validation-valid").hide();

        for (var i = 0; i < errors.length; i++) {

               var validMsg = $("span[data-valmsg-for$='" + errors[i].Key + "']");
                validMsg.html(errors[i].Value);
                validMsg.show();
        }
    };

    return _publicItems;

});