﻿app.page = (function () {

    var returnObj = {};
    var summaryTable = {};
    var ledgerTable = {};
    var taxRateTable = {};
    var mockLedgerTable = {};
    var resourseIds = [];
    var baseUrl = $("#baseUrl").val();
    var calculator = {};

    var CalculateMockTotal = function (table) {

        var tokens= $(".Tokens");
        var total = 0;

        $.each(tokens, function (i, v) {
            var token = Number($(v).text().replace(/,/gi,""));

            total = total + token;

        })
        $("#total-tokens").text(app.utils.FormatNumberWithComma(total.toFixed(0)));
        return total;
    }

    var bindings = function () {
        $("#save-ledger-button").off("click")
        $("#save-ledger-button").on("click", function () {

            var button = $(this);
            app.utils.ToggleSpin(button, 'spin')

            var obj = {};
            obj.Toon = {};
            obj.Toon.Id = $("#toonId").val();
            obj.Quantity = $("#transactionQuantity").val();
            obj.Description = $("#transactionDescription").val();
            obj.Tokens = $("#transactionTokens").val();
            obj.CreatedOn = $("#ledgerCreatedOn").val();
            obj.TransactionType = {};
            obj.TransactionType.Id = $("#transactionType").val();

            var valid = true;

            if (typeof obj.TransactionType.Id === "undefined") {
                app.utils.alerts.Error("Please select a Transaction Type");
                valid = false;
            }

            if (obj.Description === "") {
                app.utils.alerts.Error("Please enter a Description");
                valid = false;
            }

            if (obj.TransactionType.Id === "") {
                app.utils.alerts.Error("Please select a Transaction Type");
                valid = false;
            }

            if (valid) {
                $.post("/Portal/Ledger/Create", $.param(obj), function (response) {
                    if (response.Success === false) {
                        $.each(response.Messages, function (i, v) {
                            app.utils.alerts.Error(v);
                        });

                        app.utils.ToggleSpin(button, 'stop')
                        return;
                    }

                    $("#TotalFameWithdrawn").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalWithdrawnFame).toFixed(0)));
                    $("#TotalTokensWithdrawn").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalWithdrawnTokens).toFixed(1)));

                    $("#TotalItemsDeposited").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalDepositedQuantity).toFixed(0)));
                    $("#TotalTokensDeposited").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalDepositedTokens).toFixed(1)));

                    $("#TotalItemsDonated").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalDonatedQuantity).toFixed(0)));
                    $("#TotalTokensDonated").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalDonatedTokens).toFixed(1)));

                    $("#Balance").text(app.utils.FormatNumberWithComma(Number(response.Payload.Balance).toFixed(1)));

                    $("#transactionQuantity").val("");
                    $("#transactionDescription").val("");
                    $("#transactionTokens").val("");
                    $("#transactionType").selectpicker("val", "");

                    

                    if ($("#ledger-table").find(".dataTables_empty").length !== 0) $("#ledger-table").find("tbody tr").remove();

                    $("#ledger-table").find("tbody").append(response.Payload.Ledger)
                    ledgerTable.refeshFromHtml()
                    bindings();
                    app.utils.alerts.Success("Ledger Entry created");
                    app.utils.ToggleSpin(button, 'stop')
                });
            }

        });

        $(".btn-delete-ledger").off("click");
        $(".btn-delete-ledger").on("click", function () {
            var button = $(this);
            app.utils.ToggleSpin(button, 'spin')
            var row = button.parents("tr");
            var obj = {};
            obj.Id = row.find(".ledgerId").val();

            $.post("/Portal/Ledger/Delete", $.param(obj), function (response) {
                if (response.Success === false) {
                    $.each(response.Messages, function (i, v) {
                        app.utils.alerts.Error(v);
                    });

                    app.utils.ToggleSpin(button, 'stop')
                    return;
                }

                ledgerTable.removeRowData(row);

                $("#TotalFameWithdrawn").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalWithdrawnFame).toFixed(0)));
                $("#TotalTokensWithdrawn").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalWithdrawnTokens).toFixed(1)));

                $("#TotalItemsDeposited").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalDepositedQuantity).toFixed(0)));
                $("#TotalTokensDeposited").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalDepositedTokens).toFixed(1)));

                $("#TotalItemsDonated").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalDonatedQuantity).toFixed(0)));
                $("#TotalTokensDonated").text(app.utils.FormatNumberWithComma(Number(response.Payload.TotalDonatedTokens).toFixed(1)));

                $("#Balance").text(app.utils.FormatNumberWithComma(Number(response.Payload.Balance).toFixed(1), 1, ".", ","));

                app.utils.ToggleSpin(button, 'start')
            });

        });

        $("#undo-ledger-button").off("click");
        $("#undo-ledger-button").on("click", function () {

            var row = $(this).parents("tr");

            row.find("input").val("");
            row.find("select").selectpicker("val", "")
        });

        $("#add-item-to-calculations").off("click");
        $("#add-item-to-calculations").on("click", function () {
            var button = $(this);
            app.utils.ToggleSpin(button, 'spin')

            var row = $(this).parents("tr");
            var mockLedger = $("#mock-ledger-table");
            var obj = [];
            var item = {};

            item.Item = $("#itemId").val();
            item.Quality = $("#qualityId").val();
            item.Enchantment = $("#enchantments").val();
            item.Amount = $("#quantity").val();


            if (item.Item === "") {
                app.utils.alerts.Error("You must select and item");
                return;
            }
   
            obj.push(item);          

            $.post("/Portal/GatheringTax/MockDeposit", $.param({ depositLogs: obj }), function (response) {
                if (response.Success === false) {
                    $.each(response.Messages, function (i, v) {
                        app.utils.alerts.Error(v);
                    });

                    return;
                }

                if (mockLedger.find(".dataTables_empty").length !== 0) mockLedger.find("tbody tr").remove();

                mockLedger.find("tbody").append(response.Payload);
                mockLedgerTable.refeshFromHtml();

               

                 row.find("select").selectpicker("val", "");
                row.find("input[type=text]").val(0)
                bindings();
                CalculateMockTotal();

            }).always(function () {
                app.utils.ToggleSpin(button, 'stop')
            })

        })

        $(".btn-delete-mock-ledger").off("click");
        $(".btn-delete-mock-ledger").on("click", function () {         
            $(this).parents("tr").remove();
            CalculateMockTotal();
        })

        $("#reset-add-item-calculations").off("click")
        $("#reset-add-item-calculations").on("click", function () {

            var row = $(this).parents("tr");

            row.find("input").val(0);
            row.find("select").selectpicker("val", "");

        })

    }




    function createSelectPickers() {

        var options = {};

        options.iconBase = 'fas';


        $("#itemId").selectpicker(options);
        $("#qualityId").selectpicker(options);
        $("#enchantments").selectpicker(options);


        
        var selectoptions = $("#ledger-selector").find("option");

        selectoptions.attr("data-icon", "fa-spinner fa-spin hide-spinner");

        $("#ledger-selector").selectpicker(options);
    }

    returnObj.init = function () {
        calculator = new app.models.TokenCalculator($("#FameToTokenCalculator"), {});
        summaryTable = new app.models.DataTablesModel($("#balance-summary-table"), {});

        createSelectPickers();

        $("#nav-ledger-tab").on("shown.bs.tab", function () {
            if ($("#ledger-table").length > 0) ledgerTable = new app.models.DataTablesModel($("#ledger-table"), { "orderCellsTop": true, "order": ["1", "desc"] });

        });


        bindings();



        $("#ledger-selector").on("changed.bs.select", function (e, s, d, previousValue) {
            var button = $(this).parents(".bootstrap-select").find(".dropdown-toggle");

            app.utils.ToggleSpin(button, 'spin')

            var id = $(this).val();
            var obj = {};
            obj.id = id;
            var oldName;
            var title = "Bacon Tools Ledger"
            var newName = $(this).find("option:selected").text();
            if (previousValue !== "") {
                oldName = $(this).find("option[value=" + previousValue + "]").text();
                title += " - " + oldName;
            }
            if (newName === "") {
                app.utils.setUrl(title,baseUrl);
                $("#ledger-container").hide();
                return;
            }

            app.utils.setUrl(title,baseUrl + "\\" + newName );

            $.post("/Portal/Ledger/GetLedger", $.param(obj), function (response) {
                if (response.Success === false) {
                    $.each(response.Messages, function (i, v) {
                        app.utils.alerts.Error(v);
                    });
                    app.utils.ToggleSpin(button, 'stop');
                    return;
                }

                $("#ledger-container").html(response.Payload);
                $("#ledger-container").show();

                $(":input").inputmask();

                ledgerTable = new app.models.DataTablesModel($("#ledger-table"), { "orderCellsTop": true, "order": ["1", "desc"] });

                $("#transactionType").selectpicker();
                $("#ledgerCreatedOn").datetimepicker({
                    uiLibrary: 'bootstrap4',
                    footer: true,
                    format: "mm/dd/yyyy HH:MM"
                });
                bindings();
            }).always(function () {
                //app.utils.OverLay.Hide();
                app.utils.ToggleSpin(button,'stop');
            })
        })

        if ($("#Preload").val() === "True") {
            $("#nav-ledger-tab").tab('show');
            $("#ledger-selector").trigger("changed.bs.select")
        }

        if ($("#single_character_loaded").val() === "True")
        {
            $("#ledger-container").show();
        }


    }

    return returnObj;

}())