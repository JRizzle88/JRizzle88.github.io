﻿app.page = (function () {


    var returnObj = {};
    var chart = {};
    var data = {};
    var slider = {};
    var selected = function (obj) {
        var selectedItem = chart.getSelection()[0];
        if (typeof selectedItem !== "undefined") {
            var selectedValue = data.getValue(selectedItem.row, 0);

            var obj = {};
            obj.id = selectedValue;

            $.get("/Portal/GuildPositions/PositionDetails", $.param(obj), function (response) {

                if (response.Success === false) {
                    $.each(response.Messages, function (i, v) {
                        app.utils.alerts.Error(v);
                    });

                    return;
                }

                $("#org-chart-node-description").html(response.Payload)

                $("#close-position-description").off("click");
                $("#close-position-description").on("click", function () {
                    slider.slideReveal("hide");
                });

                slider.slideReveal("show");
            })
        } else {
            slider.slideReveal("hide");
        }
        

    };

    var buildOrgData = function (data) {

        var returnObj = [];

        $.each(data, function (i, v) {
            var obj = [];
            var displayObj = {};
            var div = $("<div/>");

            div.css("color", v.Color);
            div.css("font-style", "italic");
            div.text(v.Title)

            displayObj["v"] = v.Id.toString();
            displayObj["f"] = v.Toon === null ? div[0].outerHTML : v.Toon.Name + div[0].outerHTML;

            obj.push(displayObj);
            obj.push(v.ReportsToGuildPositionId === null ? "" : v.ReportsToGuildPositionId.toString());
            obj.push(v.Title);

            returnObj.push(obj);
        });

        return returnObj;

    }

    returnObj.init = function () {

        slider = $('#org-chart-node-description').slideReveal({push: false, position: "right", top: 65, width:400, height: 500})

        $('#org-chart-node-description').show();


        $.get("/Portal/GuildPositions/GetOrganization", function (response) {
            if (response.Success === false) {
                $.each(response.Messages, function (i, v) {
                    app.utils.alerts.Error(v);
                });

                return;
            }


            var dataobj = buildOrgData(response.Payload);

            google.charts.load('current', { packages: ["orgchart"] });
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                data = new google.visualization.DataTable();
                data.addColumn('string', 'Name');
                data.addColumn('string', 'Manager');
                data.addColumn('string', 'ToolTip');
                //data.addColumn('string', 'Description')
                // For each orgchart box, provide the name, manager, and tooltip to show.
                data.addRows(dataobj);

                // Create the chart.
                chart = new google.visualization.OrgChart(document.getElementById('org-chart'));
                // Draw the chart, setting the allowHtml option to true for the tooltips.
                chart.draw(data, { 'allowHtml': true });
                google.visualization.events.addListener(chart, 'select', selected);

            }
        });



    }

    return returnObj;

}());