app.page = (function () {


    var returnObj = {};
    var toonDeductions;
    var bindRowButtons = function () {

    }


    returnObj.init = function () {

        calculator = new app.models.TokenCalculator($("#FameToTokenCalculator"));
        
        toonDeductions = new app.models.DataTablesModel($("#ToonDeductions"), {});

        $("#ClearDeposit").on("click", function () {
            $("#LoadDepositsTextArea").val("")
        });


        bindRowButtons();

        $("#CalculateDues").on("click", function () {

            bootbox.confirm({
                message: "Are you sure you wish to calculate dues?",
                buttons: {
                    confirm: {
                        label: 'Yes',
                        className: 'btn-success'
                    },
                    cancel: {
                        label: 'No',
                        className: 'btn-danger'
                    }
                },
                callback: function (result) {
                    if (result === true) {
                        var button = $(this);
                        app.utils.ToggleSpin(button, 'spin');
                        $.post("/Portal/Dues/CalculateDues", null, function (response) {
                            if (response.Success === false) {
                                $.each(response.Messages, function (i, v) {
                                    app.utils.alerts.Error(v);
                                });
                                app.utils.ToggleSpin(button, 'stop');
                                return;
                            }
                            button.attr("disabled", "disabled");
                            app.utils.alerts.Success(response.Messages[0]);
                        }).always(function () {
                            app.utils.ToggleSpin(button, 'stop');
                        });
                    }

                }
            });

            

        })

        $("#LoadDeductions").on("click", function () {
            var button = $(this);
            app.utils.ToggleSpin(button, 'spin');
            var obj = {};

            obj.deductions = $("#LoadDeductionsTextArea").val();

            if (obj.deductions !== "") {

                $.post("/Portal/Dues/LoadDeductions", $.param(obj), function (response) {
                    if (response.Success === false) {
                        $.each(response.Messages, function (i, v) {
                            app.utils.alerts.Error(v);
                        });
                        app.utils.ToggleSpin(button, 'stop');
                        return;
                    }
                    $("#ProcessDeposits").attr("disabled", response.Payload === 0)
                    $("#LoadDeductionsTextArea").val("");

         
                    app.utils.alerts.Success(response.Messages[0]);
                    $("#ToonDuesStatusDiv").html(response.Payload);

                    toonDeductions = new app.models.DataTablesModel($("#ToonDeductions"), {});

                }).always(function () {
                    app.utils.ToggleSpin(button, 'stop');
                })
            } else {
                app.utils.alerts.Error("Please paste in the Deductions and try again.", true);
            }
        });

        $("#LoadDeposits").on("click", function () {
            var button = $(this);
            app.utils.ToggleSpin(button, 'spin');
            var obj = {};

            obj.deposit = $("#LoadDepositsTextArea").val();

            if (obj.deposit !== "") {

                $.post("/Portal/Dues/LoadDeposits", $.param(obj), function (response) {
                    if (response.Success === false) {
                        $.each(response.Messages, function (i, v) {
                            app.utils.alerts.Error(v);
                        });
                        app.utils.ToggleSpin(button, 'stop');
                        return;
                    }

                    $("#LoadDepositsTextArea").val("");


                    app.utils.alerts.Success(response.Messages[0]);


                }).always(function () {
                    app.utils.ToggleSpin(button, 'stop');
                })
            } else {
                app.utils.alerts.Error("Please paste in the Deductions and try again.", true);
            }
        });





        $("#LoadDepositsDiv").on("show.bs.collapse", function () {
            $("#LoadTaxDepositIcon").removeClass("fa-plus").addClass("fa-minus");
        });


        $("#LoadDepositsDiv").on("hide.bs.collapse", function () {
            $("#LoadTaxDepositIcon").removeClass("fa-minus").addClass("fa-plus");
        });


    }




    return returnObj;

}());


