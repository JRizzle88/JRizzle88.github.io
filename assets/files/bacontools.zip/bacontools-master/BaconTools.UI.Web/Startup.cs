using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using BaconTools.Repository.Interface;
using BaconTools.Repository;
using ElmahCore.Mvc;
using ElmahCore.Mvc.Notifiers;
using System.Net.Mail;
using Newtonsoft.Json.Serialization;
using System.Net;
using BaconTools.Model.Identity;
using BaconTools.Service.Core.Interface;
using BaconTools.Service.Core;
using BaconTools.Model.Core.Config;
using BaconTools.Data.Core;
using BaconTools.Data.Interfaces;
using BaconTools.Data;
using BaconTools.Data.Identity;
using System.Web.Mvc;
using Microsoft.AspNetCore.Localization;
using System.Globalization;
using System.Collections.Generic;
using BaconTools.Util;
using BaconTools.Model.Core;
using System.Linq;
using Microsoft.AspNet.Identity;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace BaconTools.UI.Web
{
    public class Startup
    {
        internal IServiceCollection service;
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            //Set up the AppSettings Object from the Settings Section of the AppSettings.json file.
            services.Configure<AppSettings>(Configuration.GetSection("Settings"));

            //This is what allows us to modify the AppSettings.json and force the application of reread the file and apply the changes.
            services.AddScoped(c => c.GetService<IOptionsSnapshot<AppSettings>>().Value);

            //AppSettingsService is the Service used to get the AppSettings Object.  AppSettingsService.AppSettings.  For the above to work the AppSettings Object 
            //must be called using the AppSettingsService.
            

            //the SP or Service Provider allows us to call Services using Dependency Injection within this Method.


            var sp = services.BuildServiceProvider();
            //Get the AppSettingsService and use the AppSettings Property to retrieve the AppSettings.
            var appSettings = sp.GetService<IOptionsSnapshot<AppSettings>>().Value;

            services.AddTransient(provider =>
            {
                var connectionString = appSettings.GetConnectionString("BaconTools");
                return new BaconToolsCoreDbContext(connectionString);
            });


            services.AddScoped<IBaconToolsDbContextFactory, BaconToolsDbContextFactory>();
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddTransient<IAppSettingsService, AppSettingsService>();
            services.AddScoped<IEmailService, EmailService>();
            services.AddScoped<ICoreUserService, CoreUserService>();
            services.AddScoped<ICurrentUserService, CurrentUserService>();
            services.AddScoped<IDuesService, DuesService>();
            services.AddScoped<IGuildPostionsService, GuildPostionsService>();
            services.AddScoped<IItemService, ItemService>();
            services.AddScoped<IToonService, ToonService>();
            services.AddScoped<IAlbionService, AlbionService>();
            services.AddScoped<ITaskService, AlbionOnlineTaskService>();
            services.AddScoped<IBuildService, BuildService>();
            services.AddScoped<ISplitService, SplitService>();

            services.AddHttpContextAccessor();
            
            
            services.AddScoped((config) => new SmtpClient
            {
                Host = appSettings.MailSettings.ServerName,
                Port = appSettings.MailSettings.ServerPort,
                EnableSsl = appSettings.MailSettings.EnableSSL,
                Credentials = new NetworkCredential(appSettings.MailSettings.UserName, appSettings.MailSettings.Password)

            });

            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(appSettings.GetConnectionString("BaconTools")));

            services.AddScoped<SignInManager<ApplicationUser>, SignInManager<ApplicationUser>>();

            services.AddDefaultIdentity<ApplicationUser>(options =>
            {
                options.User.RequireUniqueEmail = true;
                options.SignIn.RequireConfirmedEmail = true;

            }).AddRoles<IdentityRole<int>>().AddEntityFrameworkStores<ApplicationDbContext>();

            services.AddDistributedMemoryCache();
            services.AddSingleton(Configuration);
            services.AddDistributedMemoryCache();
            sp = services.BuildServiceProvider();

            var uow = sp.GetService<IUnitOfWork>();
            var albionService = sp.GetService<IAlbionService>();
            var appSettingsService = sp.GetService<IAppSettingsService>();
            var emailService = sp.GetService<IEmailService>();
            var itemService = sp.GetService<IItemService>();

            var albionOnlineTaskService = new AlbionOnlineTaskService(itemService, emailService, uow, albionService, appSettingsService);
            var tasks = new List<ITaskService>()
            {
                albionOnlineTaskService
            };

            services.AddScoped(c => tasks);
            services.AddElmah(options =>
            {
                var elmahEmailOptions = new EmailOptions
                {
                    MailRecipient = appSettings.ElmahSettings.ToString(),
                    MailSender = appSettings.MailSettings.MailFromAddress,
                    SendYsod = false,
                    SmtpServer = appSettings.MailSettings.ServerName,
                    SmtpPort = appSettings.MailSettings.ServerPort,
                    AuthPassword = appSettings.MailSettings.Password,
                    AuthUserName = appSettings.MailSettings.UserName
                };
                options.ApplicationName = "Bacon Tools";
                options.CheckPermissionAction = context => 
                    
                    context.User.Identity.IsAuthenticated && uow.GetRepository<AspNetUser>().Query(c => c.UserName == context.User.Identity.Name && c.AspNetRoles.Any(d=> d.Name == Util.Constants.UserRoles.Administrator)).Any();

                if (appSettings.Environment != "Development")
                {
                    options.Notifiers.Add(new ErrorMailNotifier("Email", elmahEmailOptions));
                }

            });

            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(60);
                options.Cookie.HttpOnly = true;
                // Make the session cookie essential
                options.Cookie.IsEssential = true;
            });

            services.ConfigureApplicationCookie(options =>
            {
                options.Cookie.HttpOnly = true;
                options.ExpireTimeSpan = TimeSpan.FromDays(365);
                options.LoginPath = "/Identity/Account/Login";
                options.LogoutPath = "/Identity/Account/Logout";
                options.AccessDeniedPath = "/Identity/Account/AccessDenied";
                options.SlidingExpiration = true;
            });


            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2).AddSessionStateTempDataProvider().AddJsonOptions(options =>
            {
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();
            });

            this.service = services;

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IApplicationLifetime lifetime)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }



            app.UseRequestLocalization(new RequestLocalizationOptions
            {
                DefaultRequestCulture = new RequestCulture(new CultureInfo("en-US")),
                SupportedCultures = new List<CultureInfo>
                {
                    new CultureInfo("en-US")
                },
                SupportedUICultures = new List<CultureInfo>
                {
                    new CultureInfo("en-US")
                }
            });
            lifetime.ApplicationStarted.Register(OnApplicationStarted);

            app.UseAuthentication();
            
            app.UseElmah();

            app.UseStaticFiles();
            app.UseCookiePolicy();
            app.UseSession();
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                  name: "MyArea",
                  template: "{area:exists}/{controller=Default}/{action=Index}/{id?}");


                routes.MapRoute("LoadLedger", "/Portal/Ledger/{*name}", defaults: new { Controller = "Ledger", action = "Index", area="Portal" });

                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");



            });
        }

        public void OnApplicationStarted()
        {

        }

    }
}
