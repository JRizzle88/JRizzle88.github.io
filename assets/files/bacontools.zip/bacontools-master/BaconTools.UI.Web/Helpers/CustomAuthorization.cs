using System.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Routing;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using BaconTools.Service.Core.Interface;
using BaconTools.Util;

namespace BaconTools.UI.Web.Helpers
{
    public class CustomAuthorizeUserAttribute : TypeFilterAttribute
    {
        public CustomAuthorizeUserAttribute(string Roles) : base(typeof(CustomAuthorizeUserFilter))
        {
            Arguments = new object[] { Roles };
        }
    }

    public class CustomAuthorizeUserFilter : Microsoft.AspNetCore.Mvc.Filters.IAuthorizationFilter
    {
        // Custom property, such as Admin|User|Anon
        public List<string> Roles { get; set; }
        private ICurrentUserService userService;
        public CustomAuthorizeUserFilter(string userRequired, ICurrentUserService userService)
        {
            this.userService = userService;
            Roles = userRequired.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
        }
        // Check to see it the user is authorized
        public void OnAuthorization(AuthorizationFilterContext context)
        {

            if (context.HttpContext.User.Identity.Name == null)
            {
                context.Result = new Microsoft.AspNetCore.Mvc.RedirectResult("/Identity/Account/Login");
            }
            else if (!userService.IsInRole(Constants.UserRoles.Administrator))
            {
                
                if(!Roles.Any(c=> userService.IsInRole(c)))
                {
                    context.Result = new Microsoft.AspNetCore.Mvc.RedirectResult("/Identity/Account/AccessDenied");
                }

            }

        }
    }
}
