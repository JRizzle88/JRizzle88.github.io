using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using BaconTools.Model.Core;
using BaconTools.Model.Core.ViewModels;
using BaconTools.Model.Identity;
using BaconTools.Service.Core;
using BaconTools.Service.Core.Interface;
using BaconTools.UI.Web.Helpers;
using BaconTools.UI.Web.Models;
using BaconTools.Util;
using BaconTools.Util.Extension;
using BaconTools.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ElmahCore;
using System.IO;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc.Filters;
using BaconTools.UI.Web.Controllers;

namespace BaconTools.UI.Web.Areas.Portal.Controllers
{
    [Area("Portal")]
    public class DuesController : BaseController
    {
        internal IDuesService duesService;
        internal IItemService itemService;
        internal IToonService toonService;
        internal IAppSettingsService appSettingsService;
        public DuesController(IToonService toonService, IHttpContextAccessor httpContextAccessor, ICurrentUserService currentUserService, IItemService itemService, IDuesService duesService, ICoreUserService coreUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
            : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.toonService = toonService;
            this.itemService = itemService;
            this.duesService = duesService;
            this.appSettingsService = appSettingsService;
        }


        [HttpGet]
        [CustomAuthorizeUser(Constants.UserRoles.DuesAdministrator)]
        public IActionResult Index()
        {
            try
            {

                ViewData["ActivePage"] = Menu.DuesAdministration;
                var toons = toonService.GetAll().Select(c=> new ToonViewModel() { 
                    AspNetUsersId = c.AspNetUsersId.HasValue ? c.AspNetUsersId.Value : 0 ,
                    Deduction = c.DuesDeduction,
                    Exempt = c.DuesExempt,
                    Id = c.Id,
                    Name = c.Name
                }).ToList();

                var lastDueCalc = appSettingsService.GetProperty(ApplicationSetting.Groups.TaxSettings, ApplicationSetting.Properties.LastDuesCalculation);
                bool canCalc = true;

                var vm = new DuesAdminViewModel()
                {
                    CanCalcDues = canCalc,
                    Toons = toons
                };

                return View(vm);
            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return RedirectToAction("Error", "Home");
            }

        }

        [HttpPost]
        [CustomAuthorizeUser(Constants.UserRoles.DuesAdministrator)]
        public IActionResult LoadDeductions(string deductions)
        {
            try
            {
                var toons = duesService.LoadDeductions(deductions).Select(c => new ToonViewModel()
                {
                    AspNetUsersId = c.AspNetUsersId.HasValue ? c.AspNetUsersId.Value : 0,
                    Deduction = c.DuesDeduction,
                    Exempt = c.DuesExempt,
                    Id = c.Id,
                    Name = c.Name
                }).ToList();
                var message = "Deductions loaded";
                var vm = RenderViewAsync("ToonDeductionsTable", toons, true).Result;
                return Json(new JsonReturn(message, true, vm));

            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return Json(new JsonReturn(ex.Message, false, null));
            }

        }

        [HttpPost]
        [CustomAuthorizeUser(Constants.UserRoles.DuesAdministrator)]
        public IActionResult CalculateDues()
        {
            try
            {
                duesService.CalculateDues();
                var message = "Dues Calculated";
                return Json(new JsonReturn(message, true));

            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return Json(new JsonReturn(ex.Message, false, null));
            }

        }

        [HttpPost]
        [CustomAuthorizeUser(Constants.UserRoles.DuesAdministrator)]
        public IActionResult LoadDeposits(string deposit)
        {
            try
            {
                var duplicates = duesService.LoadDeposits(deposit);
                var message = duplicates.Any() ? $"Deposits loaded.  There where {duplicates.Count()} duplicates." : "Deposits loaded";

                return Json(new JsonReturn(message, true));
                
            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return Json(new JsonReturn(ex.Message, false, null));
            }

        }


    }

}