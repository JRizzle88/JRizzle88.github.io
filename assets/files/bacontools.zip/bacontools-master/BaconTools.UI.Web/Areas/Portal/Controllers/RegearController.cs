﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;
using BaconTools.Model.Identity;
using BaconTools.Service.Core;
using BaconTools.Service.Core.Interface;
using BaconTools.UI.Web.Controllers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace BaconTools.UI.Web.Areas.Portal.Controllers
{
    [Area("Portal")]
    [AllowAnonymous]
    public class RegearController : BaseController
    {
        private IBuildService buildService;
        public RegearController(IBuildService buildService, IHttpContextAccessor httpContextAccessor, ICurrentUserService currentUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
            : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.buildService = buildService;

        }
        public IActionResult Index()
        {
            var build = buildService.LoadBuilFromAlbionOnline("https://albiononline.com/en/characterbuilder/solo-builds/view/37793");
            return View();
        }
    }
}