﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using BaconTools.Model.Identity;
using BaconTools.Service.Core.Interface;
using BaconTools.UI.Web.Controllers;
using BaconTools.UI.Web.Models;
using ElmahCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace BaconTools.UI.Web.Areas.Portal
{
    [Area("Portal")]
    public class DefaultController : BaseController
    {
        private IHostingEnvironment environment;
        private IGuildPostionsService guildPostionsService;

        public DefaultController(IGuildPostionsService guildPostionsService, IHttpContextAccessor httpContextAccessor, IHostingEnvironment environment, ICurrentUserService currentUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
            : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.environment = environment;
            this.guildPostionsService = guildPostionsService;
        }
        public IActionResult Index()
        {

            try
            {
                ViewData["ActivePage"] = Menu.HomeIndex;
                var path = Path.Combine(environment.WebRootPath, "images");

                var images = Directory.GetFiles(path);

                var number = new Random().Next(images.Count() - 1);
                var winner = images[number];

                var image = new FileInfo(winner);


                return View("Index", image.Name);
            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return RedirectToAction("Error", "Home");
            }
        }
    }
}