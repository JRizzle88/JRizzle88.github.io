﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BaconTools.Model.Identity;
using BaconTools.Service.Core;
using BaconTools.Service.Core.Interface;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using BaconTools.UI.Web.Helpers;
using BaconTools.Util;
using BaconTools.UI.Web.Models;
using Microsoft.AspNetCore.Http;
using BaconTools.UI.Web.Controllers;

namespace BaconTools.UI.Web.Areas.Portal.Controllers
{
    [Area("Portal")]
    [CustomAuthorizeUser(Constants.UserRoles.Administrator)]
    public class AdministrationController : BaseController
    {

        internal IDuesService gatheringTaxService;
        internal IItemService itemService;
        public AdministrationController(IHttpContextAccessor httpContextAccessor, ICurrentUserService currentUserService, IItemService itemService, IDuesService gatheringTaxService, ICoreUserService coreUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
            : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.itemService = itemService;
            this.gatheringTaxService = gatheringTaxService;
        }

        [HttpGet]
        public IActionResult Index()
        {
            ViewData["ActivePage"] = Menu.Administration;
            return View();
        }
    }
}