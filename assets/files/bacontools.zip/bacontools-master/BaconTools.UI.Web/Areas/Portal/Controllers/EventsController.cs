﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BaconTools.Model.Identity;
using BaconTools.Service.Core.Interface;
using BaconTools.UI.Web.Controllers;
using BaconTools.Web.Models;
using ElmahCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace BaconTools.UI.Web.Areas.Portal.Controllers
{
    [Area("Portal")]
    public class EventsController : BaseController
    {
        private IAlbionService albionService;
        private IEmailService emailService;
        public EventsController(IEmailService emailService,IAlbionService albionService, IHttpContextAccessor httpContextAccessor, ICurrentUserService currentUserService, IItemService itemService, ICoreUserService coreUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
       : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.emailService = emailService;
            this.albionService = albionService;
        }
        public IActionResult Index()
        {
            try
            {
                var aoEvents = albionService.GetEvent(64807269);

                return Json(new JsonReturn("AO API Return", aoEvents));
            }
            catch (Exception ex)
            {
                emailService.SendEmail("tyddlywink@gmail.com", null, null, $"TraceRoute to {ex.Data["Host"].ToString()}", ex.Data["tracert"].ToString());
                ex.Data.Clear();
                HttpContext.RiseError(ex);
                return Json(new JsonReturn(ex.Message, false, null));
            }

        }
    }
}