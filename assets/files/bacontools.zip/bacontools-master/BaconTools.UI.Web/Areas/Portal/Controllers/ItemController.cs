﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BaconTools.Model.Core;
using BaconTools.Model.Identity;
using BaconTools.Service.Core.Interface;
using BaconTools.UI.Web.Controllers;
using BaconTools.UI.Web.Models.ViewModels;
using BaconTools.Util;
using BaconTools.Web.Models;
using ElmahCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace BaconTools.UI.Web.Areas.Portal.Controllers
{
    [Area("Portal")]
    [Authorize]
    public class ItemController : BaseController
    {
        internal IItemService itemService;
        public ItemController(IHttpContextAccessor httpContextAccessor, ICurrentUserService currentUserService, IItemService itemService, ICoreUserService coreUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
            : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.itemService = itemService;
        }

        [HttpPost]
        public IActionResult GetItemSelectByTerm(string term)
        {

            try
            {
                var resourceTypes = ItemType.resourceTypes;
                var items = itemService.GetByTerm(term).OrderBy(c => c.Name).Select(c => new AjaxSelectReturn()
                {
                    css = "",
                    text = c.Name,
                    value = c.Id.ToString(),
                    disabled = false,
                    data = new Models.ViewModels.Data()
                    {
                        divider = false,
                        content = c.Name,
                        icon = "",
                        subtext = ""
                    }
                });

                return Json(items);
            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return Json(new JsonReturn(ex.Message, false, null));
            }
        }

    }
}