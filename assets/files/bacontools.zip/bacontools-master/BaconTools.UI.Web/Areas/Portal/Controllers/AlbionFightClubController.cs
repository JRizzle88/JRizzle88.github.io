﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BaconTools.Model.Identity;
using BaconTools.Service.Core;
using BaconTools.Service.Core.Interface;
using BaconTools.UI.Web.Controllers;
using BaconTools.UI.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace BaconTools.UI.Web.Areas.Portal.Controllers
{
    [Authorize]
    public class AlbionFightClubController : BaseController
    {
        internal IDuesService gatheringTaxService;
        internal IItemService itemService;
        public AlbionFightClubController(IHttpContextAccessor httpContextAccessor, ICurrentUserService currentUserService, IItemService itemService, IDuesService gatheringTaxService, ICoreUserService coreUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
            : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.itemService = itemService;
            this.gatheringTaxService = gatheringTaxService;
        }


        [Area("Portal")]
        public IActionResult Index()
        {
            ViewData["ActivePage"] = Menu.AlbionFightClub;
            return View();
        }
    }
}