﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BaconTools.Model.Identity;
using BaconTools.Service.Core.Interface;
using BaconTools.UI.Web.Controllers;
using BaconTools.UI.Web.Models;
using BaconTools.Util;
using BaconTools.Util.Extension;
using BaconTools.Web.Models;
using ElmahCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace BaconTools.UI.Web.Areas.Portal.Controllers
{
    [Area("Portal")]
    public class GuildPositionsController : BaseController
    {
        private IHostingEnvironment environment;
        private IGuildPostionsService guildPostionsService;

        public GuildPositionsController(IGuildPostionsService guildPostionsService, IHttpContextAccessor httpContextAccessor, IHostingEnvironment environment, ICurrentUserService currentUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
            : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.environment = environment;
            this.guildPostionsService = guildPostionsService;
        }

        public IActionResult Index()
        {

            try
            {
                ViewData["ActivePage"] = Menu.OrganizationChart;
                return View();
            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return RedirectToAction("Error", "Home");
            }

        }

        [HttpGet]
        public IActionResult GetOrganization()
        {
            try
            {
                var guildPostions = guildPostionsService.GetAll().ToList().To().ToList();

                return Json(new JsonReturn("", guildPostions));
            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return Json(new JsonReturn(ex.Message, false, null));
            }

        }

        [HttpGet]
        public async Task<IActionResult> PositionDetails(int id)
        {
            try
            {
                var guildPostion = guildPostionsService.GetGuildPostion(id).To();

                return await RenderJsonReturn(Constants.Views.GuildPositions.PositionDetails, guildPostion);

            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return Json(new JsonReturn(ex.Message, false, null));
            }

        }
    }
}