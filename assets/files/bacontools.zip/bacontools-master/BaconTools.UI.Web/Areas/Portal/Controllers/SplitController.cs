﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BaconTools.Model.Identity;
using BaconTools.Service.Core.Interface;
using BaconTools.UI.Web.Controllers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace BaconTools.UI.Web.Areas.Portal.Controllers
{
    [Area("Portal")]
    public class SplitController : BaseController
    {
        ISplitService splitService;

        public SplitController(ISplitService splitService, IHttpContextAccessor httpContextAccessor, ICurrentUserService currentUserService, IItemService itemService, IDuesService gatheringTaxService, ICoreUserService coreUserService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
            : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.splitService = splitService;
        }

        [Authorize]
        public IActionResult Index()
        {
            return View();
        }
    }
}