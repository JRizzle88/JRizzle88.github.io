﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BaconTools.Model.Core.ViewModels;
using BaconTools.Model.Identity;
using BaconTools.Service.Core;
using BaconTools.Service.Core.Interface;
using BaconTools.UI.Web.Controllers;
using BaconTools.UI.Web.Helpers;
using BaconTools.UI.Web.Models;
using BaconTools.Util;
using BaconTools.Util.Extension;
using BaconTools.Web.Models;
using ElmahCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BaconTools.UI.Web.Areas.Portal.Controllers
{
    [Area("Portal")]
    public class LedgerController : BaseController
    {
        internal IToonService toonService;
        internal IDuesService gatheringTaxService;
        internal IItemService itemService;
        public LedgerController(IHttpContextAccessor httpContextAccessor, IToonService toonService, ICurrentUserService currentUserService, IItemService itemService, IDuesService gatheringTaxService, IAppSettingsService appSettingsService, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole<int>> roleManager)
            : base(httpContextAccessor, roleManager, currentUserService, appSettingsService, signInManager)
        {
            this.toonService = toonService;
            this.itemService = itemService;
            this.gatheringTaxService = gatheringTaxService;
        }

        [AllowAnonymous]
        public IActionResult Index(string name)
        {

            try
            {
                ViewData["ActivePage"] = Menu.Ledger;

                var vm = new LedgerViewModel
                {
                    Summaries = gatheringTaxService.GetSummary().Select(c => new LedgerSummaryViewModel() { Name = c.name, Balance = c.total }).ToList(),
                    CanViewLedgers = false,
                };


                if (currentUserService.IsAuthenticated())
                {
                    vm.CanViewLedgers = true;
                    if (currentUserService.IsInRole(Constants.UserRoles.DuesAdministrator))
                    {
                        vm.Toons = toonService.GetAll().Select(c => new SelectListItem() { Value = c.Id.ToString(), Text = c.Name, Selected = c.Name == name }).ToList();
                        vm.GatheringTaxLedgerTableViewModel.IsAdmin = true;

                        vm.IsAdmin = true;
                        vm.GatheringTaxLedgerTableViewModel.Types = gatheringTaxService.GetTransactionTypes().Select(c => new SelectListItem() { Value = c.Id.ToString(), Text = c.Text }).ToList();
                        vm.PreLoad = !string.IsNullOrEmpty(name);
                    }
                    else
                    {
                        var user = currentUserService.User();

                        if (user.Toons.Any())
                        {

                            vm.CharacterLoaded = false;
                            if (!string.IsNullOrEmpty(name) && !user.Toons.Select(c => c.Name).Contains(name))
                            {
                                Danger($"You may not view {name}&#39;s ledger.");
                                return RedirectToAction("index", new { name = string.Empty });
                            }

                            vm.PreLoad = !string.IsNullOrEmpty(name);
                            vm.Toons = user.Toons.Select(c => new SelectListItem() { Value = c.Id.ToString(), Text = c.Name, Selected = c.Name == name }).ToList();

                            if (vm.Toons.Count() == 1)
                            {
                                vm.CharacterLoaded = true;
                                vm.GatheringTaxLedgerTableViewModel.DuesLedgers = gatheringTaxService.GetLedgers(user.Toons.First().Id).To().ToList();
                            }


                        }
                        else if (!string.IsNullOrEmpty(name))
                        {
                            Danger($"You may not view {name}&#39;s ledger.");
                            return RedirectToAction("index", new { name = string.Empty });
                        }
                    }
                    vm.GatheringTaxLedgerTableViewModel.DuesLedgers.ForEach(c => c.IsMock = false);

                }


                return View(vm);
            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return RedirectToAction("Error", "Home");
            }


        }

        [CustomAuthorizeUser(Constants.UserRoles.DuesAdministrator)]
        [HttpGet]
        public FileResult GetLedger()
        {
            var ledgers = gatheringTaxService.GetLedgers().ToList();

            var filestring = new StringBuilder();

            filestring.Append("Name");
            filestring.Append(",");
            filestring.Append("Description");
            filestring.Append(",");
            filestring.Append("Silver");
            filestring.Append(",");
            filestring.Append("Transaction Type");
            filestring.Append(",");
            filestring.Append("Created On");
            filestring.Append(",");
            filestring.Append("Created By");
            filestring.Append(@"\r\n");

            foreach (var ledger in ledgers)
            {
                filestring.Append(ledger.Toon.Name);
                filestring.Append(",");
                filestring.Append(ledger.Description);
                filestring.Append(",");
                filestring.Append(ledger.Silver);
                filestring.Append(",");
                filestring.Append(ledger.TransactionType.Text);
                filestring.Append(",");
                filestring.Append(ledger.CreatedOn.ToString());
                filestring.Append(",");
                filestring.Append(ledger.CreatedOn);
                filestring.Append(@"\r\n");
            }

            var byteArray = Encoding.ASCII.GetBytes(filestring.ToString());
            var stream = new MemoryStream(byteArray);

            return File(stream, "application/vnd.ms-excel", $"GatheringTaxLedger-{DateTime.UtcNow.ToString("MM-dd-yyyy")}.csv");
        }

        [CustomAuthorizeUser(Constants.UserRoles.DuesAdministrator)]
        [HttpPost]
        public IActionResult Delete(int Id)
        {
            try
            {
                var gatheringTaxLedger = gatheringTaxService.GetLedger(Id);
                gatheringTaxService.DeleteLedger(gatheringTaxLedger);

                var vm = new CreateLedgerEntryReturn()
                {
                    Ledger = null,
                    Groups = gatheringTaxService.GetLedgers(gatheringTaxLedger.ToonId).To().GroupBy(c => c.TransactionType.Id).Select(c => (Type: c.Key, GatheringTaxLedger: c.Select(d => d).ToList())).ToList(),
                };



                return Json(new JsonReturn("Success", true, vm));


            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return Json(new JsonReturn(ex.Message, false, null));
            }
        }

        [CustomAuthorizeUser(Constants.UserRoles.DuesAdministrator)]
        [HttpPost]
        public async Task<IActionResult> Create(DuesLedgerViewModel gatheringTaxLedgerViewModel)
        {

            try
            {
                var gatheringTaxLedger = gatheringTaxLedgerViewModel.To();


                gatheringTaxLedger.ToonId = gatheringTaxLedger.Toon.Id;
                gatheringTaxLedger.TransactionTypeId = gatheringTaxLedgerViewModel.TransactionType.Id;

                gatheringTaxLedger.Toon = null;
                gatheringTaxLedger.TransactionType = null;

                var newEntry = gatheringTaxService.CreateLedgerEntry(gatheringTaxLedger).To();
                newEntry.IsAdmin = currentUserService.IsInRole(Constants.UserRoles.DuesAdministrator);

                var vm = new CreateLedgerEntryReturn()
                {
                    Ledger = await RenderViewAsync(Constants.Views.Ledger.LedgerRow, newEntry, true),
                    Groups = gatheringTaxService.GetLedgers(newEntry.Toon.Id).To().GroupBy(c => c.TransactionType.Id).Select(c => (Type: c.Key, GatheringTaxLedger: c.Select(d => d).ToList())).ToList(),

                };



                return Json(new JsonReturn("Success", true, vm));

            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return Json(new JsonReturn(ex.Message, false, null));
            }

        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> GetLedger(int id)
        {
            try
            {
                var vm = new GatheringTaxLedgerTableViewModel();

                if (currentUserService.IsInRole(Constants.UserRoles.DuesAdministrator))
                {
                    vm.Types = gatheringTaxService.GetTransactionTypes().Select(c => new SelectListItem() { Value = c.Id.ToString(), Text = c.Text }).ToList();
                    vm.DuesLedgers = gatheringTaxService.GetLedgers(id).To().ToList();
                    vm.DuesLedgers.ForEach(c => { c.IsAdmin = true; c.IsMock = false; });
                    vm.IsAdmin = true;
                    vm.ToonId = id;

                }
                else
                {
                    var canview = currentUserService.User().Toons.Any(d => d.Id == id);

                    if (canview)
                    {
                        vm.DuesLedgers = gatheringTaxService.GetLedgers(id).To().ToList();
                        vm.DuesLedgers.ForEach(c => { c.IsAdmin = false; c.IsMock = false; });
                    }
                    else
                    {
                        return new UnauthorizedResult();
                    }
                }


                return await RenderJsonReturn(Constants.Views.Ledger.LedgerTable, vm);

            }
            catch (Exception ex)
            {
                HttpContext.RiseError(ex);
                return Json(new JsonReturn(ex.Message, false, null));
            }


        }
    }
}