using BaconTools.UI.Web.Helpers;
using BaconTools.UI.Web.Models;
using BaconTools.Web.Models;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BaconTools.UI.Web.Areas
{
    public class BasePage : PageModel
    {
        public override void OnPageHandlerSelected(PageHandlerSelectedContext filterContext)
        {
            ViewData["MyCookie"] = Request.Cookies["MenuMemory"];
            base.OnPageHandlerSelected(filterContext);
 
  
        }

        protected void Success(string message, bool dismissable = false)
        {
            AddAlert(AlertStyles.Success, message, dismissable);
        }

        protected void Danger(string message, bool dismissable = false)
        {
            AddAlert(AlertStyles.Danger, message, dismissable);
        }

        private void AddAlert(string alertStyle, string message, bool dismissable)
        {
            var alerts = TempData.ContainsKey(Alert.TempDataKey)
                ? TempData.Get<List<Alert>>(Alert.TempDataKey)
                : new List<Alert>();

            alerts.Add(new Alert
            {
                AlertStyle = alertStyle,
                Message = message,
                Dismissable = dismissable
            });

            TempData.Put(Alert.TempDataKey, alerts);
        }


    }
}
