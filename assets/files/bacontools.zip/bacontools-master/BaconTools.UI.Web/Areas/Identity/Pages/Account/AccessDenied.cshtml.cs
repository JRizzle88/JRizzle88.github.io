using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BaconTools.Service.Core.Interface;

namespace BaconTools.UI.Web.Areas.Identity.Pages.Account
{
    public class AccessDeniedModel : BasePage
    {
        private ICurrentUserService currentUserService;
        public AccessDeniedModel(ICurrentUserService currentUserService)
        {
            this.currentUserService = currentUserService;
        }

        public string role => "Admin";

        public void OnGet()
        {

        }
    }
}

