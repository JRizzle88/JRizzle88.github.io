using BaconTools.Model.Core;
using System.Collections.Generic;

namespace BaconTools.Service.Core.Interface
{
    public interface ICoreUserService 
    {
        List<AspNetUser> GetAll();
    }
}