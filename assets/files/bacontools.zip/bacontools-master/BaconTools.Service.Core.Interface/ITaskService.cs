﻿namespace BaconTools.Service.Core.Interface
{
    public interface ITaskService
    {
        void RunScheduledTasks(string key);
    }
}