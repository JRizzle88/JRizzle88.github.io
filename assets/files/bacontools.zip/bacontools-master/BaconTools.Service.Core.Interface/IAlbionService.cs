﻿using BaconTools.Model.Core.AOAPI;
using System.Collections.Generic;

namespace BaconTools.Service.Core.Interface
{
    public interface IAlbionService
    {
        List<AOEvent> GetLatestGuildEvents(int count = 50, int offset = 0, string id = "");
        Alliance GetAllianceInfo(string id = "");
        AOEvent GetEvent(int eventId);
        Guild GetGuildInfo(string id = "");
        List<Player> GetGuildMembers(string id = "");
        List<AOEvent> GetLatestEvents(int count = 50, int offset = 0);
        Player GetPlayerInfo(int id);
    }
}