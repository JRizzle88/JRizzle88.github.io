using BaconTools.Model.Core;
using System;
using System.Collections.Generic;

namespace BaconTools.Service.Core.Interface
{
    public interface IDuesService
    {
        Ledger CreateLedgerEntry(Ledger ledger);
        void DeleteLedger(Ledger ledger);
        List<Toon> LoadDeductions(string deductions);
        Ledger GetLedger(int Id);
        List<Ledger> GetLedgers(int? toonId = null);
        List<OverDueDuesModel> GetOverDueDues();
        List<(string name, int total)> GetSummary();
        List<TransactionType> GetTransactionTypes();
        List<DepositLog> LoadDeposits(string deposit);
        void CalculateDues();
    }
}