using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace BaconTools.Service.Core.Interface
{
    public interface IService<T> where T : class
    {
        T Add(T entity);
        void Delete(object key);
        void Delete(T entity);
        T Find(object key);
        IEnumerable<T> GetAll();
        IEnumerable<T> GetAll(params Expression<Func<T, object>>[] includes);
        IEnumerable<T> Query(Expression<Func<T, bool>> filter = null, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, params Expression<Func<T, object>>[] includes);
        IEnumerable<T> Query(Expression<Func<T, bool>> match);
        IEnumerable<T> Query(Expression<Func<T, bool>> filter, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy);
        T Update(T entity, object key);
    }
}