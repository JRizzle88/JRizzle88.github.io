using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Service.Core.Interface
{
    public interface IEmailService
    {
        void SendEmail(IEnumerable<string> toAddresses, IEnumerable<string> cc, IEnumerable<string> bcc, string subject, string body);
        void SendEmail(string toAddresses, string ccAddresses, string bccAddresses, string subject, string body);
    }
}
