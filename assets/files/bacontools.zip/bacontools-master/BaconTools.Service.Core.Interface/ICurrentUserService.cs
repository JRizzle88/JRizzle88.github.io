using BaconTools.Model.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Service.Core.Interface
{
    public interface ICurrentUserService
    {
        AspNetUser User();
        bool IsInRole(string role);
        IPrincipal UserPrincipal();
        bool IsAuthenticated();
        string UserName();
    }
}
