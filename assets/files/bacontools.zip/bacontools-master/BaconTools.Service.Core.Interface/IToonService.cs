﻿using BaconTools.Model.Core;
using System.Collections.Generic;

namespace BaconTools.Service.Core.Interface
{
    public interface IToonService
    {
        List<Toon> GetAll(bool includeInactive = false);
    }
}