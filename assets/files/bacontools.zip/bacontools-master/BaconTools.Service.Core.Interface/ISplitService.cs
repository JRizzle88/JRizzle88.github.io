﻿using BaconTools.Model.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Service.Core.Interface
{
    public interface ISplitService
    {
        List<SplitHeader> GetOpenSplitsCreatedByUser(string userName);
        SplitHeader GetSplit(int id);
        List<SplitHeader> GetUsersSplits(string userName);
        void MarkSplitAsPaid(int id);
        void SaveSplit(SplitHeader split);
        void AddSplitLineItem(SplitLineItem splitLineItem);
    }
}
