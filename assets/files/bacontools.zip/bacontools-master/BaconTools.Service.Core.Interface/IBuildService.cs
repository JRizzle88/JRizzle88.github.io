﻿using BaconTools.Model.Core;

namespace BaconTools.Service.Core
{
    public interface IBuildService
    {
        Build LoadBuilFromAlbionOnline(string url);
    }
}