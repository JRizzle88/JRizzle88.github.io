using BaconTools.Model.Core;
using System.Collections.Generic;

namespace BaconTools.Service.Core.Interface
{
    public interface IItemService
    {
        BuildItemLocation GetItemLocation(string src);
        List<Item> GetAll();
        string GetBaseItemUniqueName(string src);
        List<Item> GetByTerm(string term);
        int GetEnchantment(string src);
        Item GetItemByUniqueName(string uniqueName);
        List<(string Name, int Total)> GetItemNameCounts(IEnumerable<Item> src);
        List<ItemType> GetResourceItemTypes();
        int GetTier(string src);
        ItemType GetType(string src);
    }
}