using BaconTools.Model.Core;
using BaconTools.Model.Core.Config;
using System.Collections.Generic;

namespace BaconTools.Service.Core.Interface
{
    public interface IAppSettingsService
    {
        List<ApplicationSetting> GetGroup(string groupName);
        AppSettings AppSettings { get; set; }
        ApplicationSetting GetProperty(string group, string propertyName);
        ApplicationSetting SetProperty(ApplicationSetting setting);

    }
}