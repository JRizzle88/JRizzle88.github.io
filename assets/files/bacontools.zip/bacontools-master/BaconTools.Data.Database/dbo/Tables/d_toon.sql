﻿CREATE TABLE [dbo].[d_toon] (
    [Id]            INT                IDENTITY (1, 1) NOT NULL,
    [AOId]          VARCHAR (100)      NULL,
    [Name]          VARCHAR (100)      NOT NULL,
    [GuildId]       VARCHAR (100)      NULL,
    [AspNetUsersId] INT                NULL,
    [Active]        BIT                CONSTRAINT [DF_d_toon_Active] DEFAULT ((1)) NOT NULL,
    [Avatar]        VARCHAR (50)       NULL,
    [AvatarRing]    VARCHAR (50)       NULL,
    [LastTimeStamp] DATETIMEOFFSET (7) NULL,
    CONSTRAINT [PK_d_toon] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_d_toon_AspNetUsers] FOREIGN KEY ([AspNetUsersId]) REFERENCES [dbo].[AspNetUsers] ([Id])
);

