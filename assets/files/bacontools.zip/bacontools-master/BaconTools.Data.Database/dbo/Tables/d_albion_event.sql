﻿CREATE TABLE [dbo].[d_albion_event] (
    [Id]          INT                IDENTITY (1, 1) NOT NULL,
    [DateOfEvent] DATETIMEOFFSET (7) NOT NULL,
    [AOEventId]   INT                NOT NULL,
    [KillerAOId]  VARCHAR (100)      NOT NULL,
    [VictimAOId]  VARCHAR (100)      NOT NULL,
    [Type]        VARCHAR (100)      NOT NULL,
    CONSTRAINT [PK_d_ao_event] PRIMARY KEY CLUSTERED ([Id] ASC)
);

