﻿CREATE TABLE [dbo].[d_gathering_tax_ledger] (
    [Id]                INT                IDENTITY (1, 1) NOT NULL,
    [ToonId]            INT                NOT NULL,
    [Quantity]          BIGINT             NOT NULL,
    [Description]       VARCHAR (200)      NOT NULL,
    [Tokens]            DECIMAL (18, 2)    NOT NULL,
    [TransactionTypeId] INT                NOT NULL,
    [CreatedOn]         DATETIMEOFFSET (7) NOT NULL,
    [CreatedBy]         VARCHAR (100)      NOT NULL,
    CONSTRAINT [PK_d_gathering_tax_ledger] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_d_gathering_tax_ledger_d_toon] FOREIGN KEY ([ToonId]) REFERENCES [dbo].[d_toon] ([Id]),
    CONSTRAINT [FK_d_gathering_tax_ledger_l_transaction_type] FOREIGN KEY ([TransactionTypeId]) REFERENCES [dbo].[l_transaction_type] ([Id])
);

