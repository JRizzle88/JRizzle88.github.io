﻿CREATE TABLE [dbo].[l_quality] (
    [Id]   INT          NOT NULL,
    [Text] VARCHAR (15) NOT NULL,
    CONSTRAINT [PK_l_quality] PRIMARY KEY CLUSTERED ([Id] ASC)
);

