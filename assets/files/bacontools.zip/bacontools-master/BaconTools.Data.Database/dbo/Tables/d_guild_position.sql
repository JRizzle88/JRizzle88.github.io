﻿CREATE TABLE [dbo].[d_guild_position] (
    [Id]                       INT           IDENTITY (1, 1) NOT NULL,
    [Title]                    VARCHAR (150) NOT NULL,
    [Description]              VARCHAR (MAX) NOT NULL,
    [ToonId]                   INT           NULL,
    [Color]                    VARCHAR (7)   CONSTRAINT [DF_d_org_chart_hexcolor] DEFAULT ('#ffffff') NOT NULL,
    [ReportsToGuildPositionId] INT           NULL,
    CONSTRAINT [PK_d_guild_positions] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_d_guild_position_d_toon] FOREIGN KEY ([ToonId]) REFERENCES [dbo].[d_toon] ([Id]),
    CONSTRAINT [FK_d_guild_positions_d_guild_positions] FOREIGN KEY ([ReportsToGuildPositionId]) REFERENCES [dbo].[d_guild_position] ([Id])
);

