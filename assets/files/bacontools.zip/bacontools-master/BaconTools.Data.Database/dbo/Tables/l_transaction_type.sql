﻿CREATE TABLE [dbo].[l_transaction_type] (
    [Id]   INT           NOT NULL,
    [Text] VARCHAR (150) NOT NULL,
    CONSTRAINT [PK_l_transaction_type] PRIMARY KEY CLUSTERED ([Id] ASC)
);

