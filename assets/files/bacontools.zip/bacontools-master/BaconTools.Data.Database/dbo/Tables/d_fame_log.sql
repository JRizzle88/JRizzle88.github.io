﻿CREATE TABLE [dbo].[d_fame_log] (
    [Id]             INT                IDENTITY (1, 1) NOT NULL,
    [ToonId]         INT                NOT NULL,
    [FameCategoryId] INT                NOT NULL,
    [Total]          BIGINT             NOT NULL,
    [Royal]          BIGINT             NOT NULL,
    [Outlands]       BIGINT             NOT NULL,
    [Hellgate]       BIGINT             NOT NULL,
    [Timestamp]      DATETIMEOFFSET (7) NOT NULL,
    CONSTRAINT [PK_d_fame_log] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_d_fame_log_d_toon] FOREIGN KEY ([ToonId]) REFERENCES [dbo].[d_toon] ([Id]),
    CONSTRAINT [FK_d_fame_log_l_fame_category] FOREIGN KEY ([FameCategoryId]) REFERENCES [dbo].[l_fame_category] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [IX_d_fame_log]
    ON [dbo].[d_fame_log]([ToonId] ASC);

