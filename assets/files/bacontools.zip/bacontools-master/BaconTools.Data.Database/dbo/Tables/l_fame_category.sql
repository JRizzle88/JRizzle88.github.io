﻿CREATE TABLE [dbo].[l_fame_category] (
    [Id]            INT          NOT NULL,
    [Text]          VARCHAR (50) NOT NULL,
    [SubCategoryOf] INT          NULL,
    CONSTRAINT [PK_l_fame_category] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_l_fame_category_l_fame_category] FOREIGN KEY ([SubCategoryOf]) REFERENCES [dbo].[l_fame_category] ([Id])
);

