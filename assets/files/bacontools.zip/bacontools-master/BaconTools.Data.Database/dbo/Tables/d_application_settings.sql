﻿CREATE TABLE [dbo].[d_application_settings] (
    [Id]       INT           IDENTITY (1, 1) NOT NULL,
    [Group]    VARCHAR (100) NOT NULL,
    [Property] VARCHAR (100) NOT NULL,
    [Value]    VARCHAR (MAX) NOT NULL,
    CONSTRAINT [PK_d_app_settings] PRIMARY KEY CLUSTERED ([Id] ASC)
);

