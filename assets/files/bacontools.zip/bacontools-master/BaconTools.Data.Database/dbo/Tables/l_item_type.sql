﻿CREATE TABLE [dbo].[l_item_type] (
    [Id]   INT          IDENTITY (1, 1) NOT NULL,
    [Name] VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_l_item_types] PRIMARY KEY CLUSTERED ([Id] ASC)
);

