﻿CREATE TABLE [dbo].[d_tax_rate_d_gathering_tax_ledger] (
    [d_tax_rate_id]             INT NOT NULL,
    [d_gathering_tax_ledger_id] INT NOT NULL,
    CONSTRAINT [PK_d_tax_rate_d_gathering_tax_ledger] PRIMARY KEY CLUSTERED ([d_tax_rate_id] ASC, [d_gathering_tax_ledger_id] ASC),
    CONSTRAINT [FK_d_tax_rate_d_gathering_tax_ledger_d_gathering_tax_ledger] FOREIGN KEY ([d_gathering_tax_ledger_id]) REFERENCES [dbo].[d_gathering_tax_ledger] ([Id]),
    CONSTRAINT [FK_d_tax_rate_d_gathering_tax_ledger_d_tax_rate] FOREIGN KEY ([d_tax_rate_id]) REFERENCES [dbo].[d_tax_rate] ([Id])
);

