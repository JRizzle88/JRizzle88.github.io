﻿CREATE TABLE [dbo].[d_tax_rate] (
    [Id]           INT             IDENTITY (1, 1) NOT NULL,
    [Tier]         INT             NULL,
    [ItemId]       INT             NULL,
    [Exception]    BIT             NOT NULL,
    [Cap]          INT             NOT NULL,
    [TokenValue]   DECIMAL (18, 2) NOT NULL,
    [QualityId]    INT             NOT NULL,
    [Enchantments] INT             NOT NULL,
    CONSTRAINT [PK_d_tax_rate] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_d_tax_rate_l_item] FOREIGN KEY ([ItemId]) REFERENCES [dbo].[d_item] ([Id]),
    CONSTRAINT [FK_d_tax_rate_l_quality] FOREIGN KEY ([QualityId]) REFERENCES [dbo].[l_quality] ([Id])
);

