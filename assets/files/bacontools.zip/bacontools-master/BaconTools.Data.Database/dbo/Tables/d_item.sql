﻿CREATE TABLE [dbo].[d_item] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [Name]        VARCHAR (100) NOT NULL,
    [Tier]        INT           NOT NULL,
    [Enchantment] INT           NOT NULL,
    [ItemTypeId]  INT           NOT NULL,
    [Description] VARCHAR (MAX) NOT NULL,
    [UniqueName]  VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_l_item] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [CK_l_item_enchantment_max] CHECK ([Enchantment]>=(0) OR [Enchantment]>=(3)),
    CONSTRAINT [CK_l_item_tier_max] CHECK ([Tier]>=(1) OR [Tier]<=(8)),
    CONSTRAINT [FK_l_item_l_item_types] FOREIGN KEY ([ItemTypeId]) REFERENCES [dbo].[l_item_type] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [IX_l_item_Name]
    ON [dbo].[d_item]([Name] ASC);

