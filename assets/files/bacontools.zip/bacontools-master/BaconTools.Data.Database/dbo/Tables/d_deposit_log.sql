﻿CREATE TABLE [dbo].[d_deposit_log] (
    [Id]          INT                IDENTITY (1, 1) NOT NULL,
    [Date]        DATETIMEOFFSET (7) NOT NULL,
    [Toon]        VARCHAR (100)      NOT NULL,
    [Item]        VARCHAR (100)      NOT NULL,
    [Enchantment] INT                NOT NULL,
    [Quality]     INT                NOT NULL,
    [Amount]      INT                NOT NULL,
    [Processed]   BIT                DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_d_deposit_log] PRIMARY KEY CLUSTERED ([Id] ASC)
);

