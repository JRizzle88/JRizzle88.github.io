using BaconTools.Data.Core;
using BaconTools.Model.Core;
using BaconTools.Repository.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Import.Items
{ 
    
    public class Program
    {
        public static List<ItemType> itemTypes;
        public static BaconToolsCoreDbContext dbContext;
        public static ItemType unknownType;
        static void Main(string[] args)
        {
            try
            {
                
                dbContext = new BaconTools.Data.Core.BaconToolsCoreDbContext("Data Source=tydds-pc;Initial Catalog=BaconTools;Persist Security Info=True;User ID=RobsInventory;password=B0qGIDdNPfm0BEDdMn2M;Pooling=False;MultipleActiveResultSets=False;Connect Timeout=60;Encrypt=False;TrustServerCertificate=True");
                itemTypes = dbContext.ItemTypes.ToList();
                unknownType = new ItemType() { Name = "Unknown Type" };
                var silverType = new ItemType() { Name = "Silver" };
                itemTypes.Add(silverType);
                itemTypes.Add(unknownType);
                var path = @"E:\github\bacontools\Resources\items.json";
                var file = File.ReadAllText(path);
                var items = JsonConvert.DeserializeObject<List<ItemImport>>(file).Select(c => new Item()
                {
                    Description = c.LocalizedDescriptions?.ENUS ?? "",
                    Name = getName(c.LocalizedNames),
                    UniqueName = c.UniqueName,
                    Tier = getTier(c.UniqueName),
                    Enchantment = getEnchantment(c.UniqueName),
                    ItemType = getType(c.UniqueName),
                }).ToList();

                var groupItems = items.Where(c => !string.IsNullOrEmpty(c.Name)).GroupBy(c => c.Name).ToList();
                
                items = groupItems.Select(c=> new { 
                    Name = c.Key,
                    Item = c.Count() == 1 ? c.ToList() : c.Where(d=> d.Enchantment == 0).ToList()
                
                }).SelectMany(c=> c.Item).ToList();

                dbContext.Items.Add(new Item() { Description = "Silver", Enchantment = 0, ItemType = silverType, Name = "Silver", Tier = 1, UniqueName = "Silver" });
                dbContext.Items.AddRange(items);
                dbContext.TransactionTypes.AddRange(GetTransactionTypes());
                dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadLine();
            }

        }
        public static string getName(Localizednames names)
        {
            var name = names?.ENUS ?? "";
            return name;
        }

        public static List<TransactionType> GetTransactionTypes()
        {
            var types = new List<TransactionType>
            {
                new TransactionType() { Id = TransactionType.Deposit, Text = "Deposit" },
                new TransactionType() { Id = TransactionType.Withdrawal, Text = "Withdrawal" },
                new TransactionType() { Id = TransactionType.Donation, Text = "Donation" }
            };

            return types;
        }


        public static ItemType getType(string src)
        {

            if (src.Substring(0, 1).Contains("T"))
            {
                var type = src.Split('_').Skip(1).First().ToUpperInvariant();
                var itemType = itemTypes.SingleOrDefault(d => d.Name.ToUpper() == type.Replace( "@" ,"").ToUpper());
                if (itemType == null)
                {
                    type = char.ToUpper(type[0]) + type.Substring(1).ToLower();
                    itemType = new ItemType() { Name = type};

                    itemTypes.Add(itemType);
                    dbContext.ItemTypes.Add(itemType);

                }
                return itemType;
            }
            else if(src.Contains("UNIQUE"))
            {
                var itemType = itemTypes.SingleOrDefault(d => d.Name.ToUpper() == "Unique Item".ToUpper());

                if (itemType == null) 
                {
                    itemType = new ItemType() { Name = "Unique Item" };

                    itemTypes.Add(itemType);
                    dbContext.ItemTypes.Add(itemType);
                }
                return itemType;

            }
            else if(src.Contains("QUESTITEM"))
            {
                var itemType = itemTypes.SingleOrDefault(d => d.Name.ToUpper() == "Quest Item".ToUpper());

                if (itemType == null) 
                {
                    itemType = new ItemType() { Name = "Quest Item" };

                    itemTypes.Add(itemType);
                    dbContext.ItemTypes.Add(itemType);
                }
                return itemType;

            }
            else if (src.Contains("SKIN"))
            {
                var itemType = itemTypes.SingleOrDefault(d => d.Name.ToUpper() == "Skin".ToUpper());

                if (itemType == null)
                {
                    itemType = new ItemType() { Name = "Skin" };

                    itemTypes.Add(itemType);
                    dbContext.ItemTypes.Add(itemType);
                }
                return itemType;

            }
            else if (src.Contains("PLAYERISLAND_FURNITUREITEM"))
            {
                var itemType = itemTypes.SingleOrDefault(d => d.Name.ToUpper() == "Furniture Item".ToUpper());

                if (itemType == null)
                {
                    itemType = new ItemType() { Name = "Furniture Item" };

                    itemTypes.Add(itemType);
                    dbContext.ItemTypes.Add(itemType);
                }
                return itemType;

            }
            else
            {
               
                var itemType = unknownType;
                dbContext.ItemTypes.Add(itemType);
                return itemType;
            }


            
        }
        public static int getEnchantment(string src)
        {
            if (src.ToUpper().Contains("@"))
            {
                var enchantment = int.Parse(src.Split('_').Last().Split('@').Last());
                return enchantment;

            }
            return 0;
        }
        public static int getTier(string src)
        {
            if (src.ToUpper().Contains("UNIQUE") || src.ToUpper().Contains("TREASURE"))
            {
                return 0;
            }

            if (src.Substring(0, 1).Contains("T"))
            {
                var tier = int.Parse(src.Split('_').First().Replace("T", ""));
                return tier;
            }
            return 0;
        }
    }



        public class ItemImport
        {
            public string LocalizationNameVariable { get; set; }
            public string LocalizationDescriptionVariable { get; set; }
            public Localizednames LocalizedNames { get; set; }
            public Localizeddescriptions LocalizedDescriptions { get; set; }
            public string Index { get; set; }
            public string UniqueName { get; set; }
        }

        public class Localizednames
        {    
            public string ENUS { get; set; }
        }

        public class Localizeddescriptions
        {
            public string ENUS { get; set; }
        }

    
}
