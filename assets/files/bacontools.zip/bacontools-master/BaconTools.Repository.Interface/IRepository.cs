using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace BaconTools.Repository.Interface
{
    public interface IRepository<T> where T : class
    {
        T Find(object key);
        T Single(object key);
        IEnumerable<T> Query(Expression<Func<T, bool>> filter = null, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, params Expression<Func<T, object>>[] includes);
        IEnumerable<T> Query(Expression<Func<T, bool>> filter, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy);
        IEnumerable<T> Query(Expression<Func<T, bool>> match);
        IEnumerable<T> GetAll();
        IEnumerable<T> GetAll(params Expression<Func<T, object>>[] includes);
        T Update(T entity, object key);
        T Add(T entity);
        IEnumerable<T> AddRange(IEnumerable<T> entities);
        void Delete(T entity);
        void Delete(object key);
    }
}