
// ReSharper disable CheckNamespace


using BaconTools.Data.Interface;

namespace BaconTools.Data.Core
{
    public partial class BaconToolsCoreDbContext : IBaconToolsDbContext
    {

   
    }
}
