﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class CreateLedgerEntryReturn
    {
        public List<(int Type, List<DuesLedgerViewModel> GatheringTaxLedger)> Groups { private get; set; }
        private List<int> Deposits => Groups.Where(c => c.Type == TransactionType.Deposit).Select(c => c.GatheringTaxLedger.Sum(d => d.Silver)).ToList();
        private List<int> Withdrawals => Groups.Where(c => c.Type == TransactionType.Withdrawal).Select(c =>  c.GatheringTaxLedger.Sum(d => d.Silver)).ToList();

        public decimal TotalDepositedTokens => Deposits.Sum(c => c);
        public decimal TotalWithdrawnTokens => Withdrawals.Sum(c => c);
        public decimal Balance => Deposits.Sum(c => c) - Withdrawals.Sum(c => c);
        public string Ledger { get; set; }
    }
}
