using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class ToonViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool Exempt { get; set; }
        public int Deduction { get; set; }
        public int AspNetUsersId { get; set; }
    }
}
