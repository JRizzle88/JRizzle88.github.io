﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class SaveTaxSettingsViewMode
    {
        public int BaseFame { get; set; }

        public decimal TaxRate { get; set; }

        public int FreeFame { get; set; }
    }
}
