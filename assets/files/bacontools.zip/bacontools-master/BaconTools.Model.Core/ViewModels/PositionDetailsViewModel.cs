﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class PositionDetailsViewModel
    {
        public List<SelectListItem> Toons { get; set; }
        public List<SelectListItem> ReportsToPosition { get; set; }
        public GuildPositionViewModel GuildPosition { get; set; }
    }
}
