using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class GatheringTaxRateRow
    {
        public List<SelectListItem> Items { get; set; }
        public TaxRateViewModel TaxRate { get; set; } = new TaxRateViewModel();
    }
}
