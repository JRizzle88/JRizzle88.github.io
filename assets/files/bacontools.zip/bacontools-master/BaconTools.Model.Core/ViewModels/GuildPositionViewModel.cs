﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class GuildPositionViewModel
    {
        
        public int Id { get; set; } // Id (Primary key)
        public string Title { get; set; } // Title (length: 150)
        public string Description { get; set; } // Description
        public int? ToonId { get; set; } // ToonId
        public ToonViewModel Toon {get;set;}
        public string Color { get; set; } // Color (length: 7)
        public int? ReportsToGuildPositionId { get; set; } // ReportsToGuildPositionId
    }
}
