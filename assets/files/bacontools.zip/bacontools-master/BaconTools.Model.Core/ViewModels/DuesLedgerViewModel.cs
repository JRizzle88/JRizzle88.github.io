﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class DuesLedgerViewModel
    {
        public bool IsMock { get; set; }
        public int Id { get; set; } 
        public ToonViewModel Toon { get; set; } 
        public string Description { get; set; } 
        public int Silver { get; set; }
        public KeyValueViewModel TransactionType { get; set; } = new KeyValueViewModel();
        public DateTimeOffset CreatedOn { get; set; } 
        public string CreatedBy { get; set; }
        public bool IsAdmin { get; set; } = false;
    }
}
