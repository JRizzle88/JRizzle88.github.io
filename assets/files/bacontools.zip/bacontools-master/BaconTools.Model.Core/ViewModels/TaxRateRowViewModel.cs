using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class TaxRateRowViewModel
    {
        public List<SelectListItem> Items { get; set; } = new List<SelectListItem>();
        public TaxRateViewModel TaxRate { get; set; }
    }
}
