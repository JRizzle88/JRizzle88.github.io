using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class TaxRateViewModel
    {
        public int Id { get; set; }
        public int? Tier { get; set; }
        public ItemViewModel Item { get; set; } 
        public bool Exception { get; set; }       
        public decimal TokenValue { get; set; }
        public int Cap { get; set; }
        public int QualityId { get; set; }
        public string Quality { get; set; }
        public int Enchantments { get; set; }
    }
}
