﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class LedgerViewModel
    {
        public List<ApplicationSettingViewModel> TaxSettings { get; set; } = new List<ApplicationSettingViewModel>();
        public bool CharacterLoaded { get; set; }
        public List<int> ResourcesIds { get; set; }
        public ItemViewModel Item { get; set; }
        public List<TaxRateViewModel> TaxRates { get; set; }
        public List<SelectListItem> Qualities { get; set; }
        public List<SelectListItem> Items { get; set; }
        public bool PreLoad { get; set; } = false;
        public bool CanViewLedgers { get; set; } = false;
        public List<SelectListItem> Toons { get; set; } = new List<SelectListItem>();
        public List<LedgerSummaryViewModel> Summaries { get; set; } = new List<LedgerSummaryViewModel>();
        public GatheringTaxLedgerTableViewModel GatheringTaxLedgerTableViewModel { get; set; } = new GatheringTaxLedgerTableViewModel();
        public bool IsAdmin { get; set; } = false;

    }
}
