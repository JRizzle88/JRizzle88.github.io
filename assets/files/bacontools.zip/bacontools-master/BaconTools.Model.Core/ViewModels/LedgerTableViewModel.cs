﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.ViewModels
{
    public class GatheringTaxLedgerTableViewModel
    {
        public int ToonId { get; set; }
        public bool IsAdmin { get; set; } = false;
        public DuesLedgerViewModel gatheringTaxLedger { get; set; }
        public List<DuesLedgerViewModel> DuesLedgers { get; set; } = new List<DuesLedgerViewModel>();
        private List<(int Type, List<DuesLedgerViewModel> GatheringTaxLedger)> Groups => DuesLedgers.GroupBy(c => c.TransactionType.Id).Select(c => ( Type : c.Key, GatheringTaxLedger : c.Select(d => d).ToList() )).ToList();
        public List<int> Deposits => Groups.Where(c => c.Type == TransactionType.Deposit).Select(c => c.GatheringTaxLedger.Sum(d => d.Silver )).ToList();
        public List<int> Withdrawals => Groups.Where(c => c.Type == TransactionType.Withdrawal).Select(c => c.GatheringTaxLedger.Sum(d => d.Silver)).ToList();
         public decimal Balance => Deposits.Sum(c => c) - Withdrawals.Sum(c => c);
        public List<SelectListItem> Types { get; set; } = new List<SelectListItem>();
    }
}
