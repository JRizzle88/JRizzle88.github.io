﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.Config
{
    public class AOAPISettings
    {
        public string BaseUri { get; set; }
        public string GuildId { get; set; }
        public string AllianceId { get; set; }
    }
}
