using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.Config
{
    public class AppSettings
    {
        public TaskSettings TaskSettings { get; set; }
        public AOAPISettings AOAPISettings { get; set; }
        public List<ConnectionString> ConnectionStrings { get; set; }
        public string Environment { get; set; }
        public MailSettings MailSettings { get; set; }
        public ElmahSettings ElmahSettings { get; set; }
        public ImgurSettings ImgurSettings { get; set; }
        public string GetConnectionString(string connectionName)
        {
            return ConnectionStrings.Single(c => c.Name == connectionName).String;
        }

    }
    public class KeyValue
    {
        public string Key { get; set; }
        public object Value { get; set; }

    }

}
