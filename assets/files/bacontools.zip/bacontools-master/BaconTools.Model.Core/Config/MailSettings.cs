using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.Config
{
    public class MailSettings
    {
        public bool DebugEmail { get; set; }
        public List<string> DebugEmailTo { get; set; }
        public string ServerName { get; set; }
        public int ServerPort { get; set; }
        public bool EnableSSL { get; set; }
        public string MailFromAddress { get; set; }
        public string MailFromName { get; set; }

        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
