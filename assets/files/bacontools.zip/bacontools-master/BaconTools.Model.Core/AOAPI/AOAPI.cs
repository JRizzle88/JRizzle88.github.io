using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core.AOAPI
{
    public class AOEvents
    {
        public List<AOEvent> Events { get; set; }
    }

    public class AOEvent
    {
        public int numberOfParticipants { get; set; }
        public int groupMemberCount { get; set; }
        public int EventId { get; set; }
        public DateTime TimeStamp { get; set; }
        public int Version { get; set; }
        public Player Killer { get; set; }
        public Player Victim { get; set; }
        public Int64 TotalVictimKillFame { get; set; }
        public List<Player> Participants { get; set; }
        public List<Player> GroupMembers { get; set; }
        public string GvGMatch { get; set; }
        public int BattleId { get; set; }
        public string Type { get; set; }
    }

    public class Player
    {
        public float AverageItemPower { get; set; }
        public Equipment Equipment { get; set; }
        public List<Item> Inventory { get; set; }
        public string Name { get; set; }
        public string Id { get; set; }
        public string GuildName { get; set; }
        public string GuildId { get; set; }
        public string AllianceName { get; set; }
        public string AllianceId { get; set; }
        public string AllianceTag { get; set; }
        public string Avatar { get; set; }
        public string AvatarRing { get; set; }
        public long DeathFame { get; set; }
        public long KillFame { get; set; }
        public float FameRatio { get; set; }
        public Lifetimestatistics Lifetimestatistics { get; set; }

    }

    public class Equipment
    {
        public Item MainHand { get; set; }
        public Item OffHand { get; set; }
        public Item Head { get; set; }
        public Item Armor { get; set; }
        public Item Shoes { get; set; }
        public Item Bag { get; set; }
        public Item Cape { get; set; }
        public Item Mount { get; set; }
        public Item Potion { get; set; }
        public Item Food { get; set; }
    }

    public class Item
    {
        public string Type { get; set; }
        public int Count { get; set; }
        public int Quality { get; set; }
    }


    public class Inventory
    {
        public string Type { get; set; }
        public int Count { get; set; }
        public int Quality { get; set; }
    }


    public class Guild
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string FounderId { get; set; }
        public string FounderName { get; set; }
        public DateTime Founded { get; set; }
        public string AllianceTag { get; set; }
        public string AllianceId { get; set; }
        public string AllianceName { get; set; }
        public long killFame { get; set; }
        public long DeathFame { get; set; }
        public long AttacksWon { get; set; }
        public long DefensesWon { get; set; }
        public long MemberCount { get; set; }
    }


    public class Alliance
    {
        public string AllianceId { get; set; }
        public string AllianceName { get; set; }
        public string AllianceTag { get; set; }
        public string FounderId { get; set; }
        public string FounderName { get; set; }
        public DateTime Founded { get; set; }
        public List<Guild> Guilds { get; set; }
        public long NumPlayers { get; set; }
    }


    public class Lifetimestatistics
    {
        public Fame PvE { get; set; }
        public Gathering Gathering { get; set; }
        public Fame Crafting { get; set; }
        public long CrystalLeague { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
    }

    public class Fame
    {
        public long Total { get; set; }
        public long Royal { get; set; }
        public long Outlands { get; set; }
        public long Hellgate { get; set; }
    }

    public class Gathering
    {
        public Fame Fiber { get; set; }
        public Fame Hide { get; set; }
        public Fame Ore { get; set; }
        public Fame Rock { get; set; }
        public Fame Wood { get; set; }
        public Fame All { get; set; }
    }


    public class AOBuild
    {
        public int id { get; set; }
        public string title { get; set; }
        public string author { get; set; }
        public string type { get; set; }
        public DateTime createdAt { get; set; }
        public DateTime updatedAt { get; set; }
        public List<string> tags { get; set; }
        public List<int> tiers { get; set; }
        public string description { get; set; }
        public int likes { get; set; }
        public bool visible { get; set; }
        public bool published { get; set; }
        public bool featured { get; set; }
        public Items items { get; set; }
        public int groupSize { get; set; }
    }

    public class Items
    {
        public Mainhand mainhand { get; set; }
        public Head head { get; set; }
        public Armor armor { get; set; }
        public Shoes shoes { get; set; }
        public Food food { get; set; }
        public Potion potion { get; set; }
    }

    public class Mainhand
    {
        public string uniqueName { get; set; }
        public int enchantmentLevel { get; set; }
        public string categoryId { get; set; }
    }

    



    public class Head
    {
        public string uniqueName { get; set; }
        public int enchantmentLevel { get; set; }
        public string categoryId { get; set; }
    }


    
    public class Armor
    {
        public string uniqueName { get; set; }
        public int enchantmentLevel { get; set; }
        public string categoryId { get; set; }
    }

    
    public class Shoes
    {
        public string uniqueName { get; set; }
        public int enchantmentLevel { get; set; }
        public string categoryId { get; set; }
    }

   
    public class Food
    {
        public string uniqueName { get; set; }
        public int enchantmentLevel { get; set; }
        public string categoryId { get; set; }
    }


    public class Potion
    {
        public string uniqueName { get; set; }
        public int enchantmentLevel { get; set; }
        public string categoryId { get; set; }
    }


}

