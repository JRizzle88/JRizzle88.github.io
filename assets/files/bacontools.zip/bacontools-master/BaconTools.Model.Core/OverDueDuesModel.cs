using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core
{
    public class OverDueDuesModel
    {
        public Toon Toon { get; set; }
        public string LastDepositedOn { get; set; }
        public string LastDepositedItem { get; set; }
        public string TokenValue { get; set; }
        public decimal Balance { get; set; }
    }
}
