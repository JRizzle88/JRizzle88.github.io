﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core
{
    public partial class Quality
    {
        public const int All = -1;
        public const int Normal = 1;
        public const int Good = 2;
        public const int Outstanding = 3;
        public const int Excellent = 4;
        public const int Masterpiece = 5;


    }
}
