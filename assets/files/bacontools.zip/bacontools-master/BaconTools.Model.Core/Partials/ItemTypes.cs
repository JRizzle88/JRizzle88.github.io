﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core
{
    public partial class ItemType
    {
        public static List<string> resourceTypes = new List<string>()
            {
                "Wood",
                "Ore",
                "Fiber",
                //"Rock", Business Rules state we never accept stone.
                "Hide"
            };

        public static List<int> EquipmentItems = new List<int>()
        {
            22,
            36,
            39,
            56,
            57,
            58,
            59,
            60,
            61,
            67,
            69,
            70,
            68
        };
    }
}
