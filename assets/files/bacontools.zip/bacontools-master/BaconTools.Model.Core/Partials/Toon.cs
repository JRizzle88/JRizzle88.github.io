using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core
{
    public partial  class Toon
    {
        public decimal OverDueAmount() => TotalWithdrawals()-TotalDeposits();
        public decimal TaxBalance() => TotalDeposits() - TotalWithdrawals();
        public decimal TotalDeposits() => Deposits()?.Sum(c => c.Silver) ?? 0;
        public decimal TotalWithdrawals() => Withdrawels()?.Sum(c => c.Silver) ?? 0;
        public List<Ledger> Withdrawels() => Ledgers.Where(c => c.TransactionTypeId == TransactionType.Withdrawal).ToList();
        public List<Ledger> Deposits() => Ledgers.Where(c => c.TransactionTypeId == TransactionType.Deposit).ToList();
        public bool Overdue() => TaxBalance() < 0;
        public bool Overage() => TaxBalance() > 0;
    }
}
