﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core
{
    public partial class ApplicationSetting
    {
        public class Groups
        {
            public const string TaxSettings = "TaxSettings";
            public const string TaskSettings = "TaskSettings"; 
        }
        public class Properties
        {
            public const string FameTaxPercentage = "FameTaxPercentage";
            public const string FameTaxFreeFame = "FameTaxFreeFame";
            public const string FameTaxBaseFame = "FameTaxBaseFame";
            public const string SecurityKey = "SecurityKey";
            public const string LastDuesCalculation = "LastDuesCalculation";
            public const string LastToonDownload = "LastToonDownload";
        }
    }
}
