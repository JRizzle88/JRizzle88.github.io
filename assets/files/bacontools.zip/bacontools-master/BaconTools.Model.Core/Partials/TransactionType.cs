using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core
{
    public partial class TransactionType
    {
        public const int Deposit = 1;
        public const int Withdrawal = 2;
        public const int Donation = 3;
    }
}
