﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Model.Core
{
    public partial class AlbionEvent
    {
        public class EventTypes
        {
            public const string Kill = "KILL";       
        }
    }
}
