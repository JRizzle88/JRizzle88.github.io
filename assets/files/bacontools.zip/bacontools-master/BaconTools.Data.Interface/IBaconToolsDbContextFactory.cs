using BaconTools.Data.Interface;

namespace BaconTools.Data.Interfaces
{
    public interface IBaconToolsDbContextFactory
    {
        int SaveChanges();
        IBaconToolsDbContext GetDbContextForEntity<TEntity>() where TEntity : class;
    }
}
