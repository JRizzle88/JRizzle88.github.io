using BaconTools.Model.Core;
using BaconTools.Model.Core.AOAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Util
{
    public enum DeductionsColumn
    {
        player = 0,
        deduction =1,
        excempt = 2
    }

    public enum DepositColumn
    {
        date = 0,
        toon = 1,
        reason = 2,
        amount =3 
    }

    public static class TaxHelpers
    {
        public static int CalcultateTokensFromFame(Player player, Toon toon)
        {
            if (toon.DuesExempt) return 0;
            long fame = 0;
            
            fame += player.Lifetimestatistics.PvE.Total;
            fame += player.Lifetimestatistics.Crafting.Total;
            fame += player.Lifetimestatistics.Gathering.All.Total;
            fame += player.Lifetimestatistics.CrystalLeague;

            if (fame < 5000000)
            {
                return 0;
            }else if (fame >= 5000000 && fame < 10000000)
            {
                if (toon.DuesDeduction >= 100000) return 0;
                return 100000 - toon.DuesDeduction;
            }
            else if (fame >= 10000000 && fame < 20000000)
            {
                if (toon.DuesDeduction >= 125000) return 0;
                return 125000 - toon.DuesDeduction;
            }
            else
            {
                if (toon.DuesDeduction >= 200000) return 0;
                return 200000 - toon.DuesDeduction;
            }

        } 

        

        public static string GetDeductionsColumnValue(string[] columns, DeductionsColumn column)
        {
            var index = (int)column;
            return columns[index].Replace("\"",@"");
        }

        public static string GetDepositColumnValue(string[] columns, DepositColumn column)
        {
            var index = (int)column;
            return columns[index].Replace("\"", @"");
        }


    }
}
