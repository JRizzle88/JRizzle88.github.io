using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Util
{
    public static class Constants
    {
        public class Views
        {
            //public string Root = "../GatheringTax";
            public class GatheringTax
            {
                public const string Root = "../GatheringTax";
                public const string Index = "../GatheringTax/Index";
                public const string OverDueTaxes = "../GatheringTax/OverDueTaxes";
                public const string TaxRateRow = "../GatheringTax/TaxRateRow";
                public const string TaxRateTable = "../GatheringTax/TaxRateTable";
            }
            public class GuildPositions
            {

                public const string PositionDetails = "../GuildPositions/PositionDetails";

            }
            public class Ledger
            {
                public const string Root = "../Ledger";
                public const string LedgerIndex = "../Ledger/Index";
                public const string LedgerRow = "../Ledger/LedgerRow";
                public const string LedgerTable = "../Ledger/LedgerTable";
            }

            public class Administration
            {
                public const string Root = "../Administrator";
                public const string Index = "../Administrator/Index";
            }
            public class Home
            {
                public const string Root = "../Home";
                public const string Index = "../Home/Index";
            }

        }
        public class Caches
        {
            public const string Items = "Items";
        }
        public class UserRoles
        {
            public const string Administrator = "Administrator";
            public const string DuesAdministrator = "DuesAdministrator";
            public const string GuildAdmin = "GuildAdmin";
        }

    }
}
