﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Util
{
    public static class HtmlParser
    {

            public static HtmlDocument GetHtmlDocument(string url)
            {
                var htmlWeb = new HtmlWeb();
                var htmlDoc = htmlWeb.LoadFromWebAsync(url).Result;

                return htmlDoc;
            }
        
    }
}
