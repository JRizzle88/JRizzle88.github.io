﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Util
{
    public static class HttpCaller
    {
        public static TClass SendRequest<TClass>(string url) where TClass : class
        {
            try
            {
                HttpClient client = new HttpClient();
                string response = client.GetStringAsync(new Uri(url)).Result;
                var result = JsonConvert.DeserializeObject<TClass>(response);
                return result;
            }
            catch (Exception ex)
            {
                var tracert = new StringBuilder();

                try
                {


                    foreach(var ipAddress in TraceRoute.GetTraceRoute("gameinfo.albiononline.com"))
                    {
                        var response = ipAddress?.ToString();

                        if (string.IsNullOrEmpty(response))
                            response = "Time Out";

                        tracert.Append($"{response}<br/>");
                    }
                    ex.Data.Add("Host", "gameinfo.albiononline.com");
                    ex.Data.Add("tracert", tracert.ToString());
                }
                catch (Exception ex2)
                {
                    ex.Data.Add("tracert-error", ex2.Message);
                }

                throw ex;
            }

        }
    }
}
