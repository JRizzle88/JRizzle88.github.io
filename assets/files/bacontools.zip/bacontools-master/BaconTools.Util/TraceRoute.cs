using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;


namespace BaconTools.Util
{
    public static class TraceRoute
    {
        public static IEnumerable<IPAddress> GetTraceRoute(string hostname)
        {
            const int timeout = 10000;
            const int maxTTL = 30;
            const int bufferSize = 32;

            byte[] buffer = new byte[bufferSize];
            new Random().NextBytes(buffer);
            Ping pinger = new Ping();

            for (int ttl = 1; ttl <= maxTTL; ttl++)
            {
                PingOptions options = new PingOptions(ttl, true);
                PingReply reply = pinger.Send(hostname, timeout, buffer, options);
                if (reply == null)
                    throw new NullReferenceException("Replay from Ping was null.");

                if (reply.Status == IPStatus.TtlExpired)
                {
                    
                    yield return reply.Address;
                    continue;
                }
                if (reply.Status == IPStatus.TimedOut)
                {
                    
                    yield return reply.Address;
                    continue;
                }
                if (reply.Status == IPStatus.Success)
                {
                    yield return reply.Address;
                }
                break;
            }
        }
    }
}
