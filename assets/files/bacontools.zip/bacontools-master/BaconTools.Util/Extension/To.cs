using BaconTools.Model.Core;
using BaconTools.Model.Core.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Util.Extension
{
    public static class ToModels
    {

        #region Lists
        public static IEnumerable<GuildPosition> To(this IEnumerable<GuildPositionViewModel> src)
        {
            var dest = src.Select(c => c.To());
            return dest;
        }

        public static IEnumerable<GuildPositionViewModel> To(this IEnumerable<GuildPosition> src)
        {
            var dest = src.Select(c => c.To());
            return dest;
        }

        public static IEnumerable<Item> To(this IEnumerable<ItemViewModel> src)
        {
            var dest = src.Select(c => c.To());
            return dest;
        }

        public static IEnumerable<ItemViewModel> To(this IEnumerable<Item> src)
        {
            var dest = src.Select(c => c.To());
            return dest;
        }


        public static IEnumerable<KeyValueViewModel> To(this IEnumerable<ItemType> src)
        {
            var dest = src.Select(c => c.To());

            return dest;
        }

        public static IEnumerable<DuesLedgerViewModel> To(this IEnumerable<Ledger> src)
        {
            var dest = src.Select(c => c.To());
            return dest;
        }

        public static IEnumerable<Ledger> To(this IEnumerable<DuesLedgerViewModel> src)
        {
            var dest = src.Select(c => c.To());
            return dest;
        }

        public static IEnumerable<ToonViewModel> To(this IEnumerable<Toon> src)
        {
            var dest = src.Select(c => c.To());
            return dest;
        }

        public static IEnumerable<Toon> To(this IEnumerable<ToonViewModel> src)
        {
            var dest = src.Select(c => c.To());
            return dest;
        }

        public static IEnumerable<OverDueDuesViewModel> To(this IEnumerable<OverDueDuesModel> src)
        {
            var dest = src.Select(c => c.To());
            return dest;
        }

        public static IEnumerable<OverDueDuesModel> To(this IEnumerable<OverDueDuesViewModel> src)
        {
            var dest = src.Select(c => c.To());
            return dest;
        }

        #endregion

        #region Single

        public static GuildPosition To(this GuildPositionViewModel src)
        {
            var dest = new GuildPosition()
            {
                Color = src.Color,
                Description = src.Description,
                Id = src.Id,
                ReportsToGuildPositionId = src.ReportsToGuildPositionId,
                Title = src.Title,
                Toon = src.Toon?.To(),
                ToonId = src.ToonId
            };
            return dest;
        }
        public static GuildPositionViewModel To(this GuildPosition src)
        {
            var dest = new GuildPositionViewModel()
            {
                Color = src.Color,
                Description = src.Description,
                Id = src.Id,
                ReportsToGuildPositionId = src.ReportsToGuildPositionId,
                Title = src.Title,
                Toon = src.Toon?.To(),
                ToonId = src.ToonId
            };
            return dest;
        }
        public static TransactionType To(this KeyValueViewModel src)
        {
            var dest = new TransactionType()
            {
                Id = src.Id,
                Text = src.Text
            };
            return dest;
        }

        public static KeyValueViewModel To(this TransactionType src)
        {
            var dest = new KeyValueViewModel()
            {
                Id = src.Id,
                Text = src.Text
            };
            return dest;
        }


        public static DuesLedgerViewModel To(this Ledger src)
        {
            var dest = new DuesLedgerViewModel()
            {
                CreatedBy = src.CreatedBy,
                CreatedOn = src.CreatedOn,
                Description = src.Description,
                Id=src.Id,
                Silver = src.Silver,
                Toon = src.Toon.To(),
                TransactionType = src.TransactionType.To()
            };
            return dest;
        }

        public static Ledger To(this DuesLedgerViewModel src)
        {
            var dest = new Ledger()
            {
                CreatedBy = src.CreatedBy,
                CreatedOn = src.CreatedOn,
                Description = src.Description,
                Id = src.Id,
                Silver = src.Silver,
                Toon = src.Toon.To()             
            };
            return dest;
        }

        public static ToonViewModel To(this Toon src)
        {
            var dest = new ToonViewModel()
            {
                Id = src.Id,
                Name = src.Name
            };
            return dest;
        }

        public static Toon To(this ToonViewModel src)
        {
            var dest = new Toon()
            {
                Id = src.Id,
                Name = src.Name
            };
            return dest;
        }

        public static OverDueDuesViewModel To(this OverDueDuesModel src)
        {
            var dest = new OverDueDuesViewModel()
            {
                Toon = src.Toon.To(),
                Balance = src.Balance,
                LastDepositedItem = src.LastDepositedItem,
                LastDepositedOn = src.LastDepositedOn,
                TokenValue = src.TokenValue
            };
            return dest;
        }

        public static OverDueDuesModel To(this OverDueDuesViewModel src)
        {
            var dest = new OverDueDuesModel()
            {
                Toon = src.Toon.To(),
                Balance = src.Balance,
                LastDepositedItem = src.LastDepositedItem,
                LastDepositedOn = src.LastDepositedOn,
                TokenValue = src.TokenValue
            };
            return dest;
        }


        public static ItemViewModel To(this Item src)
        {
            var dest = new ItemViewModel()
            {
                UniqueName = src.UniqueName,
                Enchantment = src.Enchantment,
                Id = src.Id,
                Name = src.Name,
                ItemType = src.ItemType?.To(),
                Tier = src.Tier
            };
            return dest;
        }



        public static Item To(this ItemViewModel item)
        {
            var dest = new Item()
            {
                Enchantment = item.Enchantment,
                Id = item.Id,
                Name = item.Name,
                Tier = item.Tier
            };
            return dest;
        }

        public static KeyValueViewModel To(this ItemType src)
        {
            var dest = new KeyValueViewModel()
            {
                Id = src.Id,
                Text = src.Name
            };

            return dest;
        }
        #endregion

    }
}
