using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Util.Extension
{
    public static class Bool
    { 
        public static string ToYesNo(this bool value)
        {
            return value ? "Yes" : "No";
        }
    }
}
