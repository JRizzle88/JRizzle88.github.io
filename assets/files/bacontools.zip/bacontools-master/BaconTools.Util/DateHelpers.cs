using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Util
{
    public static class DateHelpers
    {
        public static DateTimeOffset ThisSunday()
        {
            return StartOfWeek(DateTimeOffset.UtcNow);
        }
        public static DateTimeOffset GetLastSunday()
        {
            DateTimeOffset endPrevWeek = StartOfWeek(DateTimeOffset.UtcNow).AddDays(-1);
            return StartOfWeek(endPrevWeek);
        }

        public static DateTimeOffset EndOfWeek(DateTimeOffset dateTime)
        {
            DateTimeOffset start = StartOfWeek(dateTime);

            return start.AddDays(6);
        }

        public static DateTimeOffset StartOfWeek(DateTimeOffset dateTime)
        {
            int days = dateTime.DayOfWeek - DayOfWeek.Sunday;

            if (days < 0)
                days += 7;

            return dateTime.AddDays(-1 * days).Date;
        }
    }
}
