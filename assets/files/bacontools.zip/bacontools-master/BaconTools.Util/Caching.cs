﻿using System;
using System.Collections.Generic;
using System.Runtime.Caching;

namespace BaconTools.Util
{
    public static class Caching
    {
        static object lockMe = new object();

        /// <summary>
        /// A generic method for getting and setting objects to the memory cache.
        /// </summary>
        /// <typeparam name="T">The type of the object to be returned.</typeparam>
        /// <param name="cacheItemName">The name to be used when storing this object in the cache.</param>
        /// <param name="cacheTimeInMinutes">How long to cache this object for.</param>
        /// <param name="objectSettingFunction">A parameterless function to call if the object isn't in the cache and you need to set it.</param>
        /// <returns>An object of the type you asked for</returns>
        public static T GetObjectFromCache<T>(string cacheItemName, int cacheTimeInMinutes, Func<T> objectSettingFunction)
        {
            var data = MemoryCache.Default.Get(cacheItemName);

            if (data == null)
            {
                lock (lockMe)
                {
                    data = MemoryCache.Default.Get(cacheItemName);
                    if (data != null)
                    {
                        return (T)data;
                    }

                    data = objectSettingFunction();
                    var duration = DateTimeOffset.UtcNow.AddMinutes(cacheTimeInMinutes);
                    MemoryCache.Default.AddOrGetExisting(cacheItemName, data, duration);
                }
            }
            return (T)data;
        }

        /// <summary>
        /// A generic method for getting and setting objects to the memory cache.
        /// </summary>
        /// <typeparam name="T">The type of the object to be returned.</typeparam>
        /// <param name="cacheItemName">The name to be used when storing this object in the cache.</param>
        /// <param name="cacheTimeInMinutes">How long to cache this object for.</param>
        /// <param name="value">The value to put into the cache if there is not already a value in the cache for the given key</param>
        /// <returns>An object of the type you asked for</returns>
        public static T GetObjectFromCache<T>(string cacheItemName, int cacheTimeInMinutes, object value)
        {
            var data = MemoryCache.Default.Get(cacheItemName);

            if (data == null)
            {
                lock (lockMe)
                {
                    data = MemoryCache.Default.Get(cacheItemName);
                    if (data != null)
                    {
                        return (T)data;
                    }
                    data = value;
                    var duration = DateTimeOffset.UtcNow.AddMinutes(cacheTimeInMinutes);
                    MemoryCache.Default.AddOrGetExisting(cacheItemName, data, duration);
                }
            }
            return (T)data;
        }

        public static void RemoveCacheItem(string cacheItemName)
        {
            MemoryCache.Default.Remove(cacheItemName);
        }
    }
}