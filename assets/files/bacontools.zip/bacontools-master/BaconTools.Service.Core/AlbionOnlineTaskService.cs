﻿using BaconTools.Model.Core;
using BaconTools.Model.Core.AOAPI;
using BaconTools.Model.Core.Config;
using BaconTools.Repository.Interface;
using BaconTools.Service.Core.Interface;
using BaconTools.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace BaconTools.Service.Core
{
    public class AlbionOnlineTaskService : ITaskService
    {

        private IAlbionService albionService;
        private AppSettings appSetting;
        private IAppSettingsService appSettingsService;
        private IUnitOfWork unitOfWork;
        private IEmailService emailService;
        private IItemService itemService;
        public AlbionOnlineTaskService(IItemService itemService, IEmailService emailService, IUnitOfWork unitOfWork, IAlbionService albionService, IAppSettingsService appSettingsService)
        {
            this.itemService = itemService;
            this.unitOfWork = unitOfWork;
            this.appSettingsService = appSettingsService;
            this.albionService = albionService;
            this.emailService = emailService;
            
            appSetting = appSettingsService.AppSettings;

        }
        public void RunScheduledTasks(string key)
        {
            var taskSettings = appSettingsService.GetGroup(ApplicationSetting.Groups.TaskSettings);
            var securityKey = appSetting.TaskSettings.SecurityKey;
            var lastToonDownloadSetting = taskSettings.Single(c => c.Property == ApplicationSetting.Properties.LastToonDownload);


            var lastToonDownload = DateTime.TryParse(lastToonDownloadSetting.Value, out var billy) ? billy : DateTime.UtcNow.AddDays(-1);


            var GetToons = true;
            var eventscaptured = 0;

            if (securityKey != key) return;

            var players = new List<Player>();
            appSetting.TaskSettings.GuildIds.Clear();
            appSetting.TaskSettings.GuildIds.Add("Ee81olaTRcK-hVxsYo9mNA");
            if (GetToons)
            {
                foreach (var guildId in appSetting.TaskSettings.GuildIds)
                {
                    players.AddRange(albionService.GetGuildMembers(guildId));
                }

                if (GetToons)
                {
                    UpdateGuildToons(players);
                }

                lastToonDownloadSetting.Value = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss");
                
                appSettingsService.SetProperty(lastToonDownloadSetting); 

            }


            eventscaptured = GetEvents();
            

            emailService.SendEmail("nahcol.mmo@gmail.com", null, null, "Albion Online Task Complete", $"Albion Online Task Complete<br/>Got Toons:{GetToons.ToString()}<br/>Events Captured: {eventscaptured}");

        }
        private int GetEvents()
        {
            var lastEventCaptured = unitOfWork.GetRepository<AlbionEvent>().GetAll().OrderByDescending(c=> c.AoEventId).FirstOrDefault() ?? new AlbionEvent();
            var eventscaptured = 0;
            var isMore = true;
            var offset = 0;
            do
            {
                List<AOEvent> events;
                try
                {
                    events = albionService.GetLatestEvents(50, offset);

                }
                catch (Exception)
                {
                    //Let's save the work have so far.
                    unitOfWork.SaveChanges();
                    throw;
                }

                if (lastEventCaptured.AoEventId != 0 && events.Any() && events.Select(c=> c.EventId).Contains(lastEventCaptured.AoEventId)){
                    isMore = false;
                }
                else  
                {
                    offset += 50;
                    if (offset > 1000) isMore = false;
                }
                

                foreach (var aoEvent in events.Where(c => c.Victim.AllianceId == "YTDHbAP-SA2l7cjRviSGJg").OrderBy(c => c.TimeStamp).ToList())
                {
                    if (!unitOfWork.GetRepository<AlbionEvent>().Query(c => c.AoEventId == aoEvent.EventId || aoEvent.EventId == lastEventCaptured.AoEventId).Any())
                    {
                        eventscaptured += 1;
                        var eventLog = new AlbionEvent()
                        {
                            AoEventId = aoEvent.EventId,
                            DateOfEvent = aoEvent.TimeStamp.ToUniversalTime(),
                            Type = aoEvent.Type,
                            KillerAoId = aoEvent.Killer.Id,
                            VictimAoId = aoEvent.Victim.Id,
                            GuildName = aoEvent.Victim.GuildName,
                            VictimName = aoEvent.Victim.Name
                        };
                        try
                        {
                            switch (eventLog.Type)
                            {
                                case AlbionEvent.EventTypes.Kill:
                                    eventLog.EventEquipment = GetEquiptmentForEvent(aoEvent);
                                    break;
                            };
                        }
                        catch (Exception)
                        {
                            var eventstring = JsonConvert.SerializeObject(aoEvent);
                            emailService.SendEmail("tyddlywink@gmail.com", null, null, "Error in Get Equipment", eventstring);
                            throw;
                        }


                        unitOfWork.GetRepository<AlbionEvent>().Add(eventLog);
                    }
                    
                }

            } while (isMore);

            unitOfWork.SaveChanges();

            return eventscaptured;

        }
        private EventEquipment GetEquiptmentForEvent(AOEvent aOEvent)
        {
            
            var equipments = new EventEquipment()
            {
                ArmorItem = itemService.GetItemByUniqueName(aOEvent.Victim.Equipment?.Armor?.Type),
                BagItem = itemService.GetItemByUniqueName(aOEvent.Victim.Equipment?.Bag?.Type),
                CapeItem = itemService.GetItemByUniqueName(aOEvent.Victim.Equipment?.Cape?.Type),
                HeadItem = itemService.GetItemByUniqueName(aOEvent.Victim.Equipment?.Head?.Type),
                MainHandItem = itemService.GetItemByUniqueName(aOEvent.Victim.Equipment?.MainHand?.Type),
                MountItem = itemService.GetItemByUniqueName(aOEvent.Victim.Equipment?.Mount?.Type),
                OffHandItem = itemService.GetItemByUniqueName(aOEvent.Victim.Equipment?.OffHand?.Type),
                PotionItem = itemService.GetItemByUniqueName(aOEvent.Victim.Equipment?.Potion?.Type),
                FoodItem = itemService.GetItemByUniqueName(aOEvent.Victim.Equipment?.Food?.Type),
                ShoesItem = itemService.GetItemByUniqueName(aOEvent.Victim.Equipment?.Shoes?.Type)
            };

            return equipments;

        }
        private void UpdateGuildToons(List<Player> players)
        {
            var allToons = unitOfWork.GetRepository<Toon>().GetAll().ToList();
            var AoToons = new List<Toon>();
            var inactiveMembers = allToons.Where(c => !players.Select(d => d.Name).Contains(c.Name) && c.Active).ToList();
            var activeMemebers = players.Where(c => !inactiveMembers.Select(d => d.Name).Contains(c.Name)).ToList();

            inactiveMembers.ForEach(c =>
            {
                c.Active = false;
                c.GuildId = null;
            });

            foreach (var member in activeMemebers)
            {
                var stats = member.Lifetimestatistics;
                var toon = allToons.SingleOrDefault(c => c.Name == member.Name);

                if (toon == null)
                {
                    toon = new Toon()
                    {
                        AoId = member.Id,
                        Avatar = member.Avatar,
                        Name = member.Name,
                        GuildId = member.GuildId,
                        AvatarRing = member.AvatarRing,
                        LastTimeStamp = member.Lifetimestatistics.Timestamp,
                        Active = true
                    };

                    unitOfWork.GetRepository<Toon>().Add(toon);
                }
                else if (toon.LastTimeStamp != member.Lifetimestatistics.Timestamp)
                {

                    toon.AoId = member.Id;
                    toon.GuildId = member.GuildId;
                    toon.Avatar = member.Avatar;
                    toon.AvatarRing = member.AvatarRing;
                    toon.Active = true;
                    toon.LastTimeStamp = member.Lifetimestatistics.Timestamp;
                }
            }

            unitOfWork.SaveChanges();
        }

    }
}
