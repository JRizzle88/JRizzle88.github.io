using BaconTools.Service.Core.Interface;
using System.Security.Principal;
using Microsoft.AspNetCore.Http;
using BaconTools.Util;
using BaconTools.Repository.Interface;
using BaconTools.Model.Core;
using System.Linq;

namespace BaconTools.Service.Core
{


    public class CurrentUserService : ICurrentUserService
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IPrincipal userPrincipal;
        private AspNetUser user;
        public CurrentUserService(IHttpContextAccessor httpContextAccessor, IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
            userPrincipal = httpContextAccessor.HttpContext.User;
        }

        public IPrincipal UserPrincipal()
        {
            return userPrincipal;
        }

        public bool IsInRole(string role)
        {
            if (!IsAuthenticated()) return false;

            user = User();

            if (user == null) return false;

            var inGroup = user.AspNetRoles.Any(c => c.Name == role || c.Name == Constants.UserRoles.Administrator);

            return inGroup;

        }

        public AspNetUser User()
        {
            user = user ?? unitOfWork.GetRepository<AspNetUser>().Query(c => c.UserName == userPrincipal.Identity.Name, null, c => c.AspNetRoles,c=> c.Toons).SingleOrDefault();
            return user;
        }

        public bool IsAuthenticated() => userPrincipal.Identity.IsAuthenticated;

        public string UserName()
        {
            return userPrincipal.Identity.Name;
        }
    }
}
