using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Service.Core
{
   public class DuplicateTaxRateException : Exception
    {
        public DuplicateTaxRateException(string message) : base(message) { }
    }
}
