using System;
using System.Collections.Generic;
using System.Linq;
using BaconTools.Service.Core.Interface;
using System.Linq.Expressions;
using BaconTools.Repository.Interface;

namespace BaconTools.Service.Core
{

    public class Service<T> : IService<T> where T : class
    {
        internal IUnitOfWork unitOfWork;
        internal IRepository<T> repository;
        public Service(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
            repository = unitOfWork.GetRepository<T>();
        }

        public T Find(object key)
        {
            return repository.Find(key);
        }

        public IEnumerable<T> Query(Expression<Func<T, bool>> filter = null, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, params Expression<Func<T, object>>[] includes)
        {
            return repository.Query(filter, orderBy, includes);
        }
        public IEnumerable<T> Query(Expression<Func<T, bool>> filter, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy)
        {
            return repository.Query(filter, orderBy);
        }
        public IEnumerable<T> Query(Expression<Func<T, bool>> match)
        {
            return repository.Query(match);
        }

        public IEnumerable<T> GetAll()
        {
            return repository.GetAll();
        }

        public IEnumerable<T> GetAll(params Expression<Func<T, object>>[] includes)
        {
            return repository.GetAll(includes);
        }

        public T Update(T entity, object key)
        {
            var item = repository.Update(entity, key);
            unitOfWork.SaveChanges();
            return item;
        }

        public T Add(T entity)
        {
            var item = repository.Add(entity);
            unitOfWork.SaveChanges();
            return item;
        }

        public void Delete(T entity)
        {
            repository.Delete(entity);
            unitOfWork.SaveChanges();         
        }

        public void Delete(object key)
        {
            repository.Delete(key);
            unitOfWork.SaveChanges();
        }

    }

}
