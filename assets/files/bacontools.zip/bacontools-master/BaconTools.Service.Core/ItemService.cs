using BaconTools.Model.Core;
using BaconTools.Repository.Interface;
using BaconTools.Service.Core.Interface;
using BaconTools.Util;
using System.Collections.Generic;
using System.Linq;

namespace BaconTools.Service.Core
{
    public class ItemService : IItemService
    {
        internal List<(string Name, int Total)> allItemsCounts;

        internal IUnitOfWork unitOfWork;
        public ItemService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }
        public List<ItemType> GetResourceItemTypes()
        {
            var resourceTypes = ItemType.resourceTypes;
            var itemTypes = unitOfWork.GetRepository<ItemType>().Query(c => resourceTypes.Contains(c.Name)).ToList();

            return itemTypes;
        }
        public List<Item> GetByTerm(string term) 
        {
            var itemsSearchResult = GetAll().Where(c=> term == null && c.Name != "" || c.Name.StartsWith(term)).ToList();
            return itemsSearchResult;
        }     
        public List<(string Name, int Total)> GetItemNameCounts(IEnumerable<Item> src)
        {
            return src.GroupBy(c => c.Name).Select(c =>  ( Name : c.Key, Total : c.Count() )).ToList();
        }
        public List<Item> GetAll()
        {
            var items = Util.Caching.GetObjectFromCache(Constants.Caches.Items, (60 * 24), LoadItemsForCache);
            return items;
        }
        private List<Item> AdjustNameForEnchantment(IEnumerable<Item> src)
        {
            var items = GetItemNameCounts(src).Join(src, c => c.Name, c => c.Name, (c, d) => new Item()
            {
                Description = d.Description,
                Name = c.Total == 1 ? d.Name : d.Enchantment == 0 ? d.Name : $"{d.Name}@{d.Enchantment}",
                Enchantment = d.Enchantment,
                Id = d.Id,
                ItemType = d.ItemType,
                ItemTypeId = d.ItemTypeId,
                Tier = d.Tier,
                UniqueName = d.UniqueName
            }).ToList();

            return items;
        }
        private List<Item> LoadItemsForCache()
        {
            var items = unitOfWork.GetRepository<Item>().GetAll(c => c.ItemType).Where(c=> !string.IsNullOrEmpty(c.Name)).OrderBy(c => c.Name).ToList();
            return AdjustNameForEnchantment(items);
        }
        public string GetBaseItemUniqueName(string src)
        {
            if (src.Substring(0, 1).Contains("T"))
            {
                var name = src.Split('_').ToList();
                if (name.Count >= 3)
                {
                    name.RemoveAt(0);
                    name.RemoveAt(0);

                   return string.Join("_", name);
                }
            }

            return src;

        }
        public int GetEnchantment(string src)
        {
            if (src.ToUpper().Contains("@"))
            {
                var enchantment = int.Parse(src.Split('_').Last().Split('@').Last());
                return enchantment;
            }
            return 0;
        }
        public Item GetItemByUniqueName(string uniqueName)
        {
            if (string.IsNullOrEmpty(uniqueName)) return null;

            var equipmentList = unitOfWork.GetRepository<Model.Core.Item>().Query(c => ItemType.EquipmentItems.Contains(c.ItemTypeId)).ToList();
            var name = uniqueName.Split('@')[0];
            var enchantments = int.Parse(uniqueName.Split('@').Count() == 2 ? uniqueName.Split('@')[1] : "0");
            var item = equipmentList.SingleOrDefault(c => c.UniqueName == name && c.Enchantment == enchantments);

            if (item == null)
            {
                item = equipmentList.SingleOrDefault(c => c.UniqueName == name && c.Enchantment == 0);
                if (item != null)
                {
                    item = new Model.Core.Item()
                    {
                        Description = item.Description,
                        Name = item.Name,
                        UniqueName = uniqueName,
                        Tier = item.Tier,
                        Enchantment = enchantments,
                        ItemType = item.ItemType,
                    };

                    unitOfWork.GetRepository<Model.Core.Item>().Add(item);
                }
            }

            if (item == null)
            {
                item = new Item()
                {
                    Description = "",
                    Name = uniqueName,
                    UniqueName = uniqueName,
                    Tier = GetTier(uniqueName),
                    Enchantment = GetEnchantment(uniqueName),
                    ItemType = GetType(uniqueName),
                };

                unitOfWork.GetRepository<Item>().Add(item);
            }

            return item;
        }
        public int GetTier(string src)
        {

            if (src.ToUpper().Contains("UNIQUE") || src.ToUpper().Contains("TREASURE"))
            {
                return 0;
            }

            if (src.Substring(0, 1).Contains("T"))
            {
                var tier = int.Parse(src.Split('_').First().Replace("T", ""));
                return tier;
            }

            return 0;
        }
        public BuildItemLocation GetItemLocation(string src)
        {
            var locations = unitOfWork.GetRepository<BuildItemLocation>().GetAll().ToList();
            var location = locations.SingleOrDefault(c => src.ToUpper().Contains(c.Name.ToUpper()));

            return location;
        }
        public ItemType GetType(string src)
        {
            if(src.Substring(0, 1).Contains("T"))
            {
                var type = src.Split('_').Skip(1).First().ToUpperInvariant();
                var itemType = unitOfWork.GetRepository<ItemType>().GetAll().SingleOrDefault(d => d.Name.ToUpper() == type.Replace("@", "").ToUpper());
                if (itemType == null)
                {
                    type = char.ToUpper(type[0]) + type.Substring(1).ToLower();
                    itemType = new ItemType() { Name = type };

                    unitOfWork.GetRepository<ItemType>().Add(itemType);
                }

                return itemType;
            }
            else if (src.Contains("UNIQUE"))
            {
                var itemType = unitOfWork.GetRepository<ItemType>().GetAll().SingleOrDefault(d => d.Name.ToUpper() == "Unique Item".ToUpper());

                if (itemType == null)
                {
                    itemType = new ItemType() { Name = "Unique Item" };

                    unitOfWork.GetRepository<ItemType>().Add(itemType);
                }

                return itemType;

            }
            else if (src.Contains("QUESTITEM"))
            {
                var itemType = unitOfWork.GetRepository<ItemType>().GetAll().SingleOrDefault(d => d.Name.ToUpper() == "Quest Item".ToUpper());

                if (itemType == null)
                {
                    itemType = new ItemType() { Name = "Quest Item" };

                    unitOfWork.GetRepository<ItemType>().Add(itemType);

                }

                return itemType;

            }
            else if (src.Contains("SKIN"))
            {
                var itemType = unitOfWork.GetRepository<ItemType>().GetAll().SingleOrDefault(d => d.Name.ToUpper() == "Skin".ToUpper());

                if (itemType == null)
                {
                    itemType = new ItemType() { Name = "Skin" };

                    unitOfWork.GetRepository<ItemType>().Add(itemType);
                }

                return itemType;

            }
            else if (src.Contains("PLAYERISLAND_FURNITUREITEM"))
            {
                var itemType = unitOfWork.GetRepository<ItemType>().GetAll().SingleOrDefault(d => d.Name.ToUpper() == "Furniture Item".ToUpper());

                if (itemType == null)
                {
                    itemType = new ItemType() { Name = "Furniture Item" };

                    unitOfWork.GetRepository<ItemType>().Add(itemType);

                }
                
                return itemType;

            }
            else
            {
                var itemType = unitOfWork.GetRepository<ItemType>().Query(c => c.Name == "Unknown Type").SingleOrDefault();
                return itemType;
            }
        }
    }
}
