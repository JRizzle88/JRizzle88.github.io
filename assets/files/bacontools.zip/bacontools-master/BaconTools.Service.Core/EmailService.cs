using BaconTools.Model.Core.Config;
using BaconTools.Service.Core.Interface;
using System;
using System.Collections.Generic;
using System.Net.Mail;

namespace BaconTools.Service.Core
{


    public class EmailService : IEmailService
    {
            private SmtpClient _smtpClient;
            private AppSettings _appSettings;
            public EmailService(SmtpClient smtpClient, IAppSettingsService appConfigService)
            {
                _appSettings = appConfigService.AppSettings;
                _smtpClient = smtpClient;

                smtpClient.SendCompleted += (s, e) => smtpClient.Dispose();

            }
            public void SendEmail(IEnumerable<string> toAddresses, IEnumerable<string> cc, IEnumerable<string> bcc, string subject, string body)
            {
                _smtpClient.Send(CreateMessage(toAddresses,cc,bcc, subject, body));
            }
            public void SendEmail(string toAddresses, string ccAddresses, string bccAddresses, string subject, string body)
            {
                SendEmail(new List<string>() { toAddresses }, new List<string>() { ccAddresses }, new List<string>() { bccAddresses }, subject, body);
            }

            private MailMessage CreateMessage(IEnumerable<string> toAddresses, IEnumerable<string> cc, IEnumerable<string> bcc, string subject, string body)
            {
                var message = new MailMessage();

                if (_appSettings.MailSettings.DebugEmail)
                {
                    foreach (var toAddress in _appSettings.MailSettings.DebugEmailTo)
                    {
                        message.To.Add(toAddress);
                    }
                    subject = $"Dev: {subject}";
                    body = $"<strong>This Email was generated in the Development Environment</strong><p>{body}<p>Original To Recipients:<p>{string.Join("</br>", toAddresses)}<p>Original CC Recipients<p>{string.Join("</br>", cc)}<p>Original BCC Recipients<p>{string.Join("</br>", bcc)}<p>";
                }
                else
                {
                    foreach (var address in toAddresses)
                    {
                        message.To.Add(new MailAddress(address));
                    }
                }

                message.From = new MailAddress(_appSettings.MailSettings.MailFromAddress, _appSettings.MailSettings.MailFromName);
                message.Body = body;
                message.Subject = subject;
                message.IsBodyHtml = true;

                return message;

            }
        }

    }

