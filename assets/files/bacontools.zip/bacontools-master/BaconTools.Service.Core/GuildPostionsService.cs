﻿using BaconTools.Model.Core;
using BaconTools.Repository.Interface;
using BaconTools.Service.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Service.Core
{
    public class GuildPostionsService : IGuildPostionsService
    {
        private IUnitOfWork unitOfWork;
        public GuildPostionsService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<GuildPosition> GetAll()
        {
            var guildPositions = unitOfWork.GetRepository<GuildPosition>().GetAll();
            return guildPositions;
        }
        
        public GuildPosition GetGuildPostion(int id)
        {
            var guildPosition = unitOfWork.GetRepository<GuildPosition>().Query(c => c.Id == id).SingleOrDefault();
            return guildPosition;
        }
    }
}
