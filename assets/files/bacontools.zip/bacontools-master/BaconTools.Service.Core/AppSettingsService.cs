using BaconTools.Model.Core.Config;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Options;
using BaconTools.Service.Core.Interface;
using BaconTools.Repository.Interface;
using BaconTools.Model.Core;
using System.Linq;
using System.Collections.Generic;

namespace BaconTools.Service.Core
{
    public class AppSettingsService : IAppSettingsService
    {
        public AppSettings AppSettings { get; set; }
        private IUnitOfWork unitOfWork { get; set; }
        public AppSettingsService(IOptionsSnapshot<AppSettings> values, IHostingEnvironment Environment, IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
            AppSettings = values.Value;
            AppSettings.Environment = Environment.EnvironmentName;
        }

        public List<ApplicationSetting> GetGroup (string groupName)
        {
            var group = unitOfWork.GetRepository<ApplicationSetting>().Query(c => c.Group == groupName).ToList();
            return group;
        }
        public ApplicationSetting GetProperty(string group, string propertyName)
        {
            var property = unitOfWork.GetRepository<ApplicationSetting>().Query(c => c.Group == group && c.Property == propertyName).SingleOrDefault();
            if (property == null)
            {
                property = new ApplicationSetting()
                {
                    Group = group,
                    Property = propertyName
                };

                unitOfWork.GetRepository<ApplicationSetting>().Add(property);
                
            }

            return property;
        }

        public ApplicationSetting SetProperty(ApplicationSetting setting)
        {
            var property = unitOfWork.GetRepository<ApplicationSetting>().Query(c => c.Group == setting.Group && c.Property == setting.Property).SingleOrDefault();
            if (property == null)
            {
                property = new ApplicationSetting();

                unitOfWork.GetRepository<ApplicationSetting>().Add(property);

            }

            property.Group = setting.Group;
            property.Property = setting.Property;
            property.Value = setting.Value;

            unitOfWork.SaveChanges();
            return property;
        }


    }
}
