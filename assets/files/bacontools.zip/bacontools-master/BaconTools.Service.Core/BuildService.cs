﻿using BaconTools.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ScrapySharp.Extensions;
using BaconTools.Model.Core;
using BaconTools.Model.Core.AOAPI;
using BaconTools.Util;
using BaconTools.Service.Core.Interface;

namespace BaconTools.Service.Core
{
    public class BuildService : IBuildService
    {
        private const string AlbionOnlineUrl = "https://albiononline.com/en/characterbuilder";
        private IUnitOfWork unitOfWork;
        private IItemService itemService;
        public BuildService(IUnitOfWork unitOfWork, IItemService itemService)
        {
            this.itemService = itemService;
            this.unitOfWork = unitOfWork;
        }

        public Build LoadBuilFromAlbionOnline(string url)
        {
            throw new NotImplementedException();
        }

    }
}
