﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using Newtonsoft.Json;
using BaconTools.Model.Core.AOAPI;
using BaconTools.Service.Core.Interface;
using BaconTools.Util;

namespace BaconTools.Service.Core
{
    public class AlbionService : IAlbionService
    {
        private readonly string baseUri;
        private string guildId;
        private string allianceId;
        private IEmailService emailService;

        public AlbionService(IAppSettingsService appSettingsService, IEmailService emailService)
        {
            var appSettings = appSettingsService.AppSettings;
            baseUri = appSettings.AOAPISettings.BaseUri;
            guildId = appSettings.AOAPISettings.GuildId;
            allianceId = appSettings.AOAPISettings.AllianceId;
            this.emailService = emailService;
        }

        private TClass MakeCall<TClass>(string url) where TClass : class
        {
            try
            {
                return HttpCaller.SendRequest<TClass>($"{baseUri}{url}");
            }
            catch (Exception)
            {
                emailService.SendEmail("tyddlywink@gmail.com", null, null, "Albion URL Call", url);
                throw;
            }   
            
        }

        public List<AOEvent> GetLatestEvents(int count = 50, int offset = 0)
        {
            return MakeCall<List<AOEvent>>($"events?limit={count}&offset={offset}");
        }
        public List<AOEvent> GetLatestGuildEvents(int count = 50, int offset = 0, string id="")
        {
            id = (id == "") ? this.guildId : id;
            return MakeCall<List<AOEvent>>($"events?limit={count}&offset={offset}&guildId={id}");
        }

        public Player GetPlayerInfo(int id)
        {
            return MakeCall<Player>($"players/{id}");
        }

        public Guild GetGuildInfo(string id = "")
        {
            id = (id == "") ? this.guildId : id; // default to BACON guild if not passing id
            return MakeCall<Guild>($"guilds/{id}");
        }

        public List<Player> GetGuildMembers(string id = "")
        {
            id = (id == "") ? this.guildId : id; // default to BACON members if not passing id
            return MakeCall<List<Player>>($"guilds/{id}/members");
        }

        public Alliance GetAllianceInfo(string id = "")
        {
            id = (id == "") ? this.allianceId : id; // default to BACON alliance if not passing id
            return MakeCall<Alliance>($"alliances/{id}");
        }
        public AOEvent GetEvent(int eventId)
        {
            return MakeCall<AOEvent>($"events/{eventId}");
        }
    }

}
