using BaconTools.Model.Core;
using BaconTools.Model.Core.ViewModels;
using BaconTools.Repository.Interface;
using BaconTools.Service.Core.Interface;
using BaconTools.Util;
using System;
using System.Collections.Generic;
using System.Linq;


namespace BaconTools.Service.Core
{

    public class DuesService : IDuesService
    {
        internal IItemService itemService;
        internal ICurrentUserService currentUserService;
        internal IUnitOfWork unitOfWork;
        internal IAppSettingsService appSettingsService;
        internal IAlbionService albionService;

        public DuesService(IAlbionService albionService, IAppSettingsService appSettingsService, IUnitOfWork unitOfWork, ICurrentUserService currentUserService, IItemService itemService)
        {
            this.albionService = albionService;
            this.appSettingsService = appSettingsService;
            this.itemService = itemService;
            this.currentUserService = currentUserService;
            this.unitOfWork = unitOfWork;
        }

        public Ledger GetLedger(int Id)
        {
            var ledger = unitOfWork.GetRepository<Ledger>().Query(c => c.Id == Id, null, c => c.Toon, c => c.TransactionType).Single();
            return ledger;
        }

        public List<TransactionType> GetTransactionTypes()
        {
            var types = unitOfWork.GetRepository<TransactionType>().GetAll().ToList();
            return types;
        }

        public void DeleteLedger(Ledger gatheringTaxLedger)
        {
            unitOfWork.GetRepository<Ledger>().Delete(gatheringTaxLedger);
            unitOfWork.SaveChanges();
        }

        public Ledger CreateLedgerEntry(Ledger ledger)
        {
            ledger.CreatedBy = currentUserService.User()?.DisplayName ?? currentUserService.UserName();
            ledger.CreatedOn = ledger.CreatedOn == DateTimeOffset.MinValue ? DateTimeOffset.UtcNow : ledger.CreatedOn;
            unitOfWork.GetRepository<Ledger>().Add(ledger);
            unitOfWork.SaveChanges();
            var newLedgerEntry = unitOfWork.GetRepository<Ledger>().Query(c => c.Id == ledger.Id, null, c => c.Toon, c => c.TransactionType).Single();
            return newLedgerEntry;
        }
        public List<ApplicationSetting> GetTaxGroupApplicationSettings()
        {
            var group = unitOfWork.GetRepository<ApplicationSetting>().Query(c => c.Group == ApplicationSetting.Groups.TaxSettings).ToList();
            return group;

        }

        public void CalculateDues()
        {
            var lastSunday = DateHelpers.GetLastSunday();
            var guildId = appSettingsService.AppSettings.AOAPISettings.GuildId;
            var baconsMembers = albionService.GetGuildMembers(guildId);
            foreach (var player in baconsMembers)
            {
                var toon = unitOfWork.GetRepository<Toon>().Query(c => c.AoId == player.Id).SingleOrDefault();

                if (toon == null)
                {
                    toon = new Toon()
                    {
                        Name = player.Name,
                        AvatarRing = player.AvatarRing,
                        Avatar = player.Avatar,
                        GuildId = player.GuildId,
                        AoId = player.Id,
                        Active = true,
                        DuesExempt = false,
                        DuesDeduction = 0
                    };

                    unitOfWork.GetRepository<Toon>().Add(toon);

                }

                var dues = Util.TaxHelpers.CalcultateTokensFromFame(player,toon);

                if (dues > 0)
                {
                    var ledger = new Ledger()
                    {
                        CreatedOn = DateTime.UtcNow,
                        CreatedBy = currentUserService.User().DisplayName,
                        Description = $"Guild dues for the week of {lastSunday.UtcDateTime.ToLongDateString()}",
                        TransactionTypeId = TransactionType.Withdrawal,
                        Silver = dues
                    };

                    toon.Ledgers.Add(ledger);

                }
            }

            unitOfWork.SaveChanges();
            var LastDueDatePull = appSettingsService.GetProperty(ApplicationSetting.Groups.TaxSettings, ApplicationSetting.Properties.LastDuesCalculation);
            LastDueDatePull.Value = DateTime.UtcNow.Date.ToShortDateString();
            appSettingsService.SetProperty(LastDueDatePull);
        }

        public List<Toon> LoadDeductions(string deductions)
        {
            var deductionsList = new List<DepositLog>();
            var deductionRows = deductions.Split(new string[] { "\n", "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries).ToList();

            foreach (var deductionRow in deductionRows)
            {
                var columns = deductionRow.Split(new string[] { "\t" }, System.StringSplitOptions.RemoveEmptyEntries);
                var toonName = TaxHelpers.GetDeductionsColumnValue(columns, DeductionsColumn.player);
                var deduction = int.Parse(TaxHelpers.GetDeductionsColumnValue(columns, DeductionsColumn.deduction).Replace(",",""));
                var exempt = bool.Parse(TaxHelpers.GetDeductionsColumnValue(columns, DeductionsColumn.excempt).Replace("Yes","True").Replace("No", "False"));
                var toon = unitOfWork.GetRepository<Toon>().Query(c => c.Name == toonName).FirstOrDefault();

                toon.DuesDeduction = deduction;
                toon.DuesExempt = exempt;

            }

            unitOfWork.GetRepository<DepositLog>().AddRange(deductionsList);
            var toons = unitOfWork.GetRepository<Toon>().Query(c => c.Active).OrderBy(c=> c.Name).ToList();
            unitOfWork.SaveChanges();
            return toons;
        }

        public List<DepositLog> LoadDeposits(string deposit)
        {
            var deposits = new List<DepositLog>();
            var depositRows = deposit.Split(new string[] { "\n", "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries).ToList();

            depositRows.RemoveAt(0);

            foreach (var depositRow in depositRows)
            {
                var columns = depositRow.Split(new string[] { "\t" }, System.StringSplitOptions.RemoveEmptyEntries);
                var depositLog = new DepositLog()
                {
                    Reason = TaxHelpers.GetDepositColumnValue(columns, DepositColumn.reason),
                    Player = TaxHelpers.GetDepositColumnValue(columns, DepositColumn.toon),
                    Date = DateTime.Parse(TaxHelpers.GetDepositColumnValue(columns, DepositColumn.date)),
                    Amount = int.Parse(TaxHelpers.GetDepositColumnValue(columns, DepositColumn.amount)),
                };
                deposits.Add(depositLog);
            }

            var firstDate = deposits.OrderBy(c => c.Date).FirstOrDefault().Date.AddMinutes(-1);
            var depositsOnOrAfter = unitOfWork.GetRepository<DepositLog>().Query(c => c.Date >= firstDate).Select(c => $"{c.Date.ToString() }-{c.Player}").ToList();
            var duplicates = deposits.Where(c => depositsOnOrAfter.Contains($"{c.Date.ToString()}-{c.Player}")).ToList();

            deposits = deposits.Where(c => !duplicates.Contains(c)).ToList();
            unitOfWork.GetRepository<DepositLog>().AddRange(deposits);

            foreach(var dep in deposits.Where(c=> c.Amount > 0))
            {
                var toon = unitOfWork.GetRepository<Toon>().Query(c => c.Name == dep.Player).SingleOrDefault();
                if (toon != null)
                {
                    var ledger = new Ledger()
                    {
                        CreatedBy = currentUserService.User().DisplayName,
                        CreatedOn = DateTime.UtcNow,
                        Silver = dep.Amount,
                        Description = "Silver Deposit into Guild Bank",
                        TransactionTypeId = TransactionType.Deposit,
                    };
                    toon.Ledgers.Add(ledger);
                }
            }

            unitOfWork.SaveChanges();
            return duplicates;
        }

        public List<Ledger> GetLedgers(int? toonId = null)
        {
            var ledgers = unitOfWork.GetRepository<Ledger>().Query(c => toonId == null || c.ToonId == toonId, null, c => c.Toon, c => c.TransactionType).ToList();
            return ledgers;
        }

        public List<(string name, int total)> GetSummary()
        {


            var ledgerSummary = unitOfWork.GetRepository<Ledger>()
                .GetAll(c => c.Toon).GroupBy(c => c.Toon.Name)
                .Select(c => new
                {
                    Name = c.Key,
                    Withdrawal =
                        c.Where(d => d.TransactionTypeId == TransactionType.Withdrawal).Select(d => d.Silver).Sum(d => d),
                    Deposits =
                        c.Where(d => d.TransactionTypeId == TransactionType.Deposit).Select(d => d.Silver).Sum(d => d)
                })
                .Select(c => (name: c.Name, total: c.Deposits - c.Withdrawal)).ToList();

            return ledgerSummary;
        }


        public List<OverDueDuesModel> GetOverDueDues()
        {
            var overDueTaxes = new List<OverDueDuesModel>();

            var toons = unitOfWork.GetRepository<Toon>().GetAll().ToList().Where(c => c.Overdue()).ToList();

            foreach (var toon in toons)
            {
                var lastDeposit = toon.Deposits().OrderByDescending(c => c.CreatedOn).FirstOrDefault();
                var overDueTax = new OverDueDuesModel()
                {
                    Balance = toon.OverDueAmount(),
                    LastDepositedItem = lastDeposit?.Description ?? "N/A",
                    LastDepositedOn = lastDeposit?.CreatedOn.UtcDateTime.ToString("MM/dd/yyy HH:mm") ?? "N/A",
                    TokenValue = lastDeposit?.Silver.ToString("N1") ?? "N/A",
                    Toon = toon
                };

                overDueTaxes.Add(overDueTax);
            }

            return overDueTaxes;
        }

        public List<OverDueDuesModel> GetOverageDues()
        {
            var overDueTaxes = new List<OverDueDuesModel>();

            var toons = unitOfWork.GetRepository<Toon>().GetAll().ToList().Where(c => c.Overage()).ToList();

            foreach (var toon in toons)
            {
                var lastDeposit = toon.Deposits().OrderByDescending(c => c.CreatedOn).FirstOrDefault();
                var overDueTax = new OverDueDuesModel()
                {
                    Balance = toon.OverDueAmount() * -1,
                    LastDepositedItem = lastDeposit?.Description ?? "N/A",
                    LastDepositedOn = lastDeposit?.CreatedOn.UtcDateTime.ToString("MM/dd/yyy HH:mm") ?? "N/A",
                    TokenValue = lastDeposit?.Silver.ToString("N1") ?? "N/A",
                    Toon = toon
                };

                overDueTaxes.Add(overDueTax);
            }

            return overDueTaxes;
        }


        private Toon GetToonByName(string toonName)
        {
            var toon = unitOfWork.GetRepository<Toon>().Query(c => c.Name == toonName).SingleOrDefault();

            if (toon == null)
            {
                toon = new Toon()
                {
                    Name = toonName
                };

                unitOfWork.GetRepository<Toon>().Add(toon);
            }

            return toon;
        }

    }
}
