using BaconTools.Model.Core;
using BaconTools.Repository.Interface;
using BaconTools.Service.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Service.Core
{
    public class CoreUserService :  ICoreUserService
    {
        private IUnitOfWork unitOfWork;
        public CoreUserService(IUnitOfWork unitOfWork) 
        {
            this.unitOfWork = unitOfWork;
        }

        public List<AspNetUser> GetAll()
        {
            var users = unitOfWork.GetRepository<AspNetUser>().GetAll().ToList();
            return users;
        }

    }
}
