﻿using BaconTools.Model.Core;
using BaconTools.Repository.Interface;
using BaconTools.Service.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaconTools.Service.Core
{


    public class SplitService : ISplitService
    {

        IUnitOfWork unitOfWork;

        public SplitService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public void SaveSplit(SplitHeader split)
        {
            unitOfWork.GetRepository<SplitHeader>().Add(split);
            unitOfWork.SaveChanges();
        }

        public List<SplitHeader> GetUsersSplits(string userName)
        {
            var splits = unitOfWork.GetRepository<SplitHeader>().Query(c => c.SplitLineItems.Any(d => d.Toon.AspNetUser.UserName == userName && !d.Paid), null, c => c.SplitLineItems).ToList();

            foreach (var split in splits)
            {
                var userSplits = split.SplitLineItems.Where(c => c.Toon.AspNetUser.UserName == userName).ToList();
                split.SplitLineItems = userSplits;
            }

            return splits;

        }

        public List<SplitHeader> GetOpenSplitsCreatedByUser(string userName)
        {
            var splits = unitOfWork.GetRepository<SplitHeader>().Query(c => c.CreatedBy == userName && c.CreatedOn.Date.AddDays(30) <= DateTime.Today && c.SplitLineItems.Any(d => !d.Paid), null, c => c.SplitLineItems).ToList();

            return splits;
        }


        public SplitHeader GetSplit(int id)
        {
            var split = unitOfWork.GetRepository<SplitHeader>().Query(c => c.Id == id, null, c => c.SplitLineItems).Single();

            return split;
        }

        public void AddSplitLineItem(SplitLineItem splitLineItem)
        {
            unitOfWork.GetRepository<SplitLineItem>().Add(splitLineItem);
            unitOfWork.SaveChanges();
        }

        public void MarkSplitAsPaid(int id)
        {
            var split = unitOfWork.GetRepository<SplitLineItem>().Query(c => c.Id == id).Single();
            split.Paid = true;
            unitOfWork.SaveChanges();
        }
    }
}
